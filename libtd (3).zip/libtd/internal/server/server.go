// Package server — собирает все зависимости в один Server struct
// и регистрирует HTTP-маршруты на chi-роутере.
package server

import (
        "context"
        "net/http"

        "github.com/go-chi/chi/v5"
        "github.com/libtd/libtd/internal/auth"
        "github.com/libtd/libtd/internal/config"
        "github.com/libtd/libtd/internal/db"
        "github.com/libtd/libtd/internal/handlers"
        "github.com/libtd/libtd/internal/middleware"
        "github.com/libtd/libtd/internal/storage"
        "github.com/libtd/libtd/internal/templates"
)

// Server — агрегатор всех зависимостей приложения.
type Server struct {
        Cfg      *config.Config
        DB       *db.DB
        Storage  storage.FileStorage
        Auth     *auth.Sessions
        PoW      *auth.PoW
        Keys     auth.Keys
        Tmpls    *templates.Renderer
        Handlers *handlers.Handlers
        Router   http.Handler
}

// New создаёт Server из конфига и зависимостей.
func New(cfg *config.Config, database *db.DB, store storage.FileStorage) (*Server, error) {
        r, err := templates.New()
        if err != nil {
                return nil, err
        }

        sessions := &auth.Sessions{
                DB:    database,
                Key:   []byte(cfg.SessionKey),
                TTL:   cfg.SessionTTL,
                Secure: cfg.CookieSecure,
        }
        pow := &auth.PoW{
                DB:           database,
                ChallengeLen: cfg.PoWChallengeLen,
                TTL:          cfg.PoWTTL,
        }
        keys := auth.Keys{}

        h := &handlers.Handlers{
                Cfg:      cfg,
                DB:       database,
                Storage:  store,
                Auth:     sessions,
                PoW:      pow,
                Keys:     keys,
                Tmpls:    r,
        }

        srv := &Server{
                Cfg:      cfg,
                DB:       database,
                Storage:  store,
                Auth:     sessions,
                PoW:      pow,
                Keys:     keys,
                Tmpls:    r,
                Handlers: h,
        }
        srv.Router = srv.buildRouter()
        return srv, nil
}

// buildRouter монтирует все маршруты на chi.
func (s *Server) buildRouter() http.Handler {
        r := chi.NewRouter()

        // Глобальный middleware: аутентификация (не блокирующая).
        // ВАЖНО: r.Use должен вызываться ДО регистрации любого маршрута,
        // иначе chi запанирует ("all middlewares must be defined before routes").
        r.Use(middleware.Auth(s.Auth))

        // Статика: CSS/JS встроены в бинарник (работает из любой рабочей директории).
        // Uploads — отдельная папка (runtime data), не встраивается.
        r.Handle("/static/*", http.StripPrefix("/static/", http.FileServer(staticFilesystem())))
        r.Handle("/uploads/*", http.StripPrefix("/uploads/", http.FileServer(http.Dir(s.Cfg.UploadDir))))

        // Публичные страницы.
        r.Get("/", s.Handlers.Home)
        r.Get("/login", s.Handlers.LoginPage)
        r.Post("/login", s.Handlers.LoginSubmit)
        r.Get("/register", s.Handlers.RegisterPage)
        r.Post("/register", s.Handlers.RegisterSubmit)
        r.Post("/logout", s.Handlers.Logout)

        // PoW — отдача challenge (фронтенд запрашивает перед отправкой формы).
        r.Get("/pow/{purpose}", s.Handlers.PowChallenge)

        // Доски (динамический slug).
        r.Get("/{boardSlug}", s.Handlers.BoardView)
        r.With(middleware.RequireAuth).Get("/{boardSlug}/new", s.Handlers.NewThreadPage)
        r.With(middleware.RequireAuth).Post("/{boardSlug}/new", s.Handlers.NewThreadSubmit)
        r.Get("/{boardSlug}/{threadID:\\d+}", s.Handlers.ThreadView)
        r.With(middleware.RequireAuth).Post("/{boardSlug}/{threadID:\\d+}/reply", s.Handlers.ReplySubmit)
        r.With(middleware.RequireAuth).Post("/{boardSlug}/{threadID:\\d+}/reply/{replyID:\\d+}", s.Handlers.ReplySubmit)
        r.With(middleware.RequireAuth).Delete("/{boardSlug}/thread/{threadID:\\d+}", s.Handlers.DeleteThread)

        // Подписки на доски.
        r.With(middleware.RequireAuth).Post("/subscribe/{boardID:\\d+}", s.Handlers.Subscribe)
        r.With(middleware.RequireAuth).Post("/unsubscribe/{boardID:\\d+}", s.Handlers.Unsubscribe)

        // Предложения досок.
        r.Get("/suggestions", s.Handlers.SuggestionsPage)
        r.With(middleware.RequireAuth).Post("/suggestions", s.Handlers.SuggestionCreate)
        r.With(middleware.RequireAuth).Post("/suggestions/{id:\\d+}/vote", s.Handlers.SuggestionVote)

        // Админка — только супер-админ. Используем r.With (а не r.Group+Use),
        // т.к. chi требует, чтобы все middleware были зарегистрированы до первого маршрута.
        r.With(middleware.RequireSuperAdmin).Get("/admin", s.Handlers.AdminPage)
        r.With(middleware.RequireSuperAdmin).Post("/admin/settings/max-file-size", s.Handlers.AdminSetMaxFileSize)
        r.With(middleware.RequireSuperAdmin).Post("/admin/users/{id:\\d+}/role", s.Handlers.AdminSetUserRole)
        r.With(middleware.RequireSuperAdmin).Delete("/admin/users/{id:\\d+}", s.Handlers.AdminDeleteUser)
        r.With(middleware.RequireSuperAdmin).Delete("/admin/replies/{id:\\d+}", s.Handlers.AdminDeleteReply)
        r.With(middleware.RequireSuperAdmin).Post("/admin/suggestions/{id:\\d+}/approve", s.Handlers.AdminApproveSuggestion)
        r.With(middleware.RequireSuperAdmin).Post("/admin/boards", s.Handlers.AdminCreateBoard)

        // 404
        r.NotFound(s.Handlers.NotFound)

        return r
}

// Shutdown корректно закрывает пул БД.
func (s *Server) Shutdown(ctx context.Context) error {
        s.DB.Close()
        return nil
}
