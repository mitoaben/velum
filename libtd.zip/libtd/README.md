# libtd

Anonymous, key-based forum built with Go + HTMX + PostgreSQL.

**Key feature:** no passwords. Authentication uses ED25519 keypairs + Proof-of-Work.

## Quick start

```bash
# 1. Have PostgreSQL running. Create DB + user:
createuser -P libtd   # password: libtd
createdb -O libtd libtd

# 2. Copy .env.example -> .env and tweak if needed:
cp .env.example .env

# 3. Run:
make run
# or: go run ./cmd/server

# 4. Open http://localhost:8080
# First registered user becomes Super Admin.
```

## Stack

- **Backend:** Go 1.23+, `net/http` + `chi/v5` router, `pgx/v5` for PostgreSQL.
- **Frontend:** `html/template` + HTMX + hyperscript + Tailwind (CDN).
- **Storage:** pluggable `FileStorage` interface — `LocalFS` by default, drop-in S3 stub included.
- **Auth:** ED25519 PEM keys + PoW (SHA-256 substring) + DB-backed sessions signed with HMAC.

## Project layout

```
libtd/
├── cmd/server/main.go              # точка входа
├── internal/
│   ├── auth/                       # PoW, ED25519 keys, sessions
│   ├── config/                     # env-based config
│   ├── db/                         # pgx pool + queries + migrations
│   │   └── migrations/001_init.sql
│   ├── handlers/                   # HTTP handlers (auth, threads, replies, suggestions, admin)
│   ├── middleware/                 # auth, require-auth, require-super-admin
│   ├── models/                     # domain types
│   ├── server/                     # DI + chi router
│   ├── storage/                    # FileStorage interface + LocalFS + S3 stub
│   └── templates/                  # html/template renderer + embedded templates
│       ├── pages/                  # full-page templates
│       ├── partials/               # header, footer
│       └── fragments/              # HTMX-rendered partials
├── web/
│   ├── static/
│   │   ├── css/app.css
│   │   └── js/app.js               # PoW solver, HTMX helpers
└── uploads/                        # LocalFS root (gitkeep)
```

## Authentication flow

### Register

1. User picks a nickname, gets a PoW challenge (4–5 chars).
2. JS solves PoW: finds N such that `SHA-256(challenge + ":" + N)` contains `challenge`.
3. Backend verifies PoW, generates an ED25519 keypair.
4. **Public key** is stored in `users.public_key`.
5. **Private key** (PKCS8, PEM-encoded) is downloaded as `libtd_<nickname>.key`.
6. User is auto-logged-in.
7. **First registered user automatically becomes `is_super_admin = TRUE`.**

### Login

1. User uploads `.key` (drag-and-drop or file picker) OR pastes PEM text.
2. Solves a fresh PoW.
3. Backend looks up user by nickname, parses the private key, generates a random 32-byte nonce.
4. Signs nonce with the private key (server-side), verifies with the public key from DB.
5. If valid → creates a session, sets signed HMAC cookie.

### Why sign server-side?

We don't trust the client with the nonce — instead, we prove that **the private key
corresponds to the public key in DB**. The signature is computed on the server in
the scope of a single request; the key is never persisted anywhere except the
user's machine.

## Forum features

- **Boards** with slugs. Default board is `all` (auto-created).
- **Threads** with title, content, multiple attachments (images, video, any file up to 100 MB by default).
- **Replies** with **nested tree** structure.
  - Replying to a specific reply renders a clickable quote block:
    `[Nickname #ID] → [parent content truncated to 100 chars]`.
  - Click scrolls to the original reply.
- **Suggestions** — users propose new boards. Anyone can vote (one vote per user).
- **Subscriptions** — users subscribe to boards; subscribed boards appear as extra tabs in the header.
- **Roles:**
  - **Super Admin** (first user): full admin panel access.
  - **Moderator** (per board): can delete threads/replies in their board.
  - **Regular user**: can post, reply, vote, subscribe.
- **Approve suggestion** in admin panel: creates a new board + auto-promotes the suggester to moderator of that board.

## Admin panel (`/admin`, super-admin only)

- Change max file size (stored in DB `settings` table, hot-reloadable).
- Promote/demote moderators, delete users (super-admin is protected).
- Delete any reply.
- Approve board suggestions (auto-creates board + moderator).
- Create boards manually.
- View basic stats.

## File storage

The `FileStorage` interface has 4 methods: `Save / Open / Delete / URL`.

- `LocalFS` (default): saves to `./uploads/<hex>/<hex>/<filename>` (two-level sharding).
  Files are served from `/uploads/...` via `http.FileServer`.
- `S3Storage`: stub with full method signatures. To activate:
  1. `go get github.com/aws/aws-sdk-go-v2/service/s3`
  2. Implement `Save/Open/Delete` (URL already works).
  3. Set `STORAGE_KIND=s3` and S3_* env vars.
  
  The rest of the code does not change — that's the whole point of the interface.

## Configuration

All settings come from env vars (see `.env.example`). Highlights:

| Var | Default | Description |
|-----|---------|-------------|
| `DATABASE_URL` | `postgres://libtd:libtd@localhost:5432/libtd?sslmode=disable` | PostgreSQL DSN |
| `ADDR` | `:8080` | HTTP listen address |
| `SESSION_KEY` | (dev default) | HMAC key for session cookies — **change in prod** |
| `SESSION_TTL` | `720h` (30d) | Session lifetime |
| `COOKIE_SECURE` | `false` | Set `true` if HTTPS |
| `POW_CHALLENGE_LEN` | `4` | 3..6; 4–5 recommended |
| `POW_TTL` | `5m` | Challenge validity |
| `MAX_FILE_SIZE` | `104857600` (100 MB) | Per-file upload limit (overridable from admin) |
| `UPLOAD_DIR` | `./uploads` | LocalFS root |
| `STORAGE_KIND` | `local` | `local` or `s3` |
| `S3_*` | — | See `.env.example` |
| `APP_ENV` | `dev` | `dev` shows error details; `prod` hides them |

## Security notes

- **PoW** mitigates brute-force / spam registration. Each challenge is single-use and time-limited.
- **Session cookies** are `HttpOnly`, `SameSite=Lax`, optionally `Secure`, and signed with HMAC-SHA256. Tokens are 32 random bytes (base64url).
- **File uploads** are saved with sanitized names + random two-level directory sharding to prevent traversal and collisions.
- **Multipart form** parsing uses `MaxBytesReader` and `ParseMultipartForm(maxSize)` to prevent OOM.
- **Admin actions** are protected by middleware + handler-level checks (super-admin can't be deleted, role-changed, etc.).
- **CSRF**: state-changing routes use POST/DELETE + SameSite cookies. For full CSRF protection (e.g., for a public deployment), add a CSRF token library — the current setup relies on SameSite=Lax which covers most cases.

## Development

```bash
make run        # go run ./cmd/server
make build      # go build -o bin/libtd ./cmd/server
make tidy       # go mod tidy
make vet        # go vet ./...
make test       # go test ./...
```

## License

MIT — see source headers.
