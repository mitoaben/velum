// Команда libtd запускает HTTP-сервер форума.
//
// Порядок запуска:
//   1. Читаем конфиг из env (config.Load).
//   2. Открываем пул к PostgreSQL и прогоняем миграции.
//   3. Инициализируем FileStorage (LocalFS или S3 — по config.StorageKind).
//   4. Собираем Server (DI всех зависимостей) и запускаем http.Server.
//
// ПоSIGTERM/SIGINT сервер плавно завершает работу (graceful shutdown).
package main

import (
	"context"
	"errors"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/libtd/libtd/internal/config"
	"github.com/libtd/libtd/internal/db"
	"github.com/libtd/libtd/internal/server"
	"github.com/libtd/libtd/internal/storage"
)

func main() {
	configPath := flag.String("config", "", "path to .env file (optional; env vars have priority)")
	flag.Parse()

	if *configPath != "" {
		if err := loadEnvFile(*configPath); err != nil {
			log.Fatalf("load .env: %v", err)
		}
	}

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("config load: %v", err)
	}

	// 1) БД
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	database, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("db open: %v", err)
	}
	defer database.Close()

	// 2) Storage
	var store storage.FileStorage
	switch cfg.StorageKind {
	case "s3":
		s3store, err := storage.NewS3(cfg.S3Endpoint, cfg.S3Region, cfg.S3Bucket,
			cfg.S3AccessKey, cfg.S3SecretKey, cfg.S3UsePath, cfg.S3PublicURL)
		if err != nil {
			log.Fatalf("s3 init: %v", err)
		}
		store = s3store
		log.Println("WARNING: S3 storage is in stub mode. See internal/storage/s3.go for activation instructions.")
	default:
		lstore, err := storage.NewLocalFS(cfg.UploadDir, "/uploads")
		if err != nil {
			log.Fatalf("local fs init: %v", err)
		}
		store = lstore
		log.Printf("Storage: LocalFS at %s", cfg.UploadDir)
	}

	// 3) Server
	srv, err := server.New(cfg, database, store)
	if err != nil {
		log.Fatalf("server init: %v", err)
	}

	// 4) Background: cleanup expired PoW + sessions каждые 5 минут
	go cleanupLoop(database)

	// 5) HTTP server
	httpSrv := &http.Server{
		Addr:              cfg.Addr,
		Handler:           srv.Router,
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       60 * time.Second,
		WriteTimeout:      120 * time.Second, // для больших аплоадов
		IdleTimeout:       120 * time.Second,
	}

	// 6) Graceful shutdown
	go func() {
		log.Printf("libtd listening on %s (env=%s)", cfg.Addr, cfg.Env)
		if err := httpSrv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("listen: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	log.Println("shutting down...")

	shutCtx, shutCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutCancel()
	if err := httpSrv.Shutdown(shutCtx); err != nil {
		log.Printf("shutdown: %v", err)
	}
	_ = srv.Shutdown(shutCtx)
	log.Println("bye")
}

// cleanupLoop периодически чистит протухшие PoW и сессии.
func cleanupLoop(database *db.DB) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	for range t.C {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		if err := database.CleanupExpiredChallenges(ctx); err != nil {
			log.Printf("cleanup: %v", err)
		}
		cancel()
	}
}

// loadEnvFile загружает .env файл в environ. Простая реализация: KEY=VALUE построчно.
func loadEnvFile(path string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	for _, line := range splitLines(string(data)) {
		line = trimSpace(line)
		if line == "" || line[0] == '#' {
			continue
		}
		idx := indexByte(line, '=')
		if idx <= 0 {
			continue
		}
		key := trimSpace(line[:idx])
		val := trimSpace(line[idx+1:])
		// Не перезаписываем уже заданные env-переменные.
		if _, ok := os.LookupEnv(key); !ok {
			_ = os.Setenv(key, val)
		}
	}
	return nil
}

// --- tiny stdlib helpers to avoid importing extra packages ---

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			line := s[start:i]
			if len(line) > 0 && line[len(line)-1] == '\r' {
				line = line[:len(line)-1]
			}
			out = append(out, line)
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}

func trimSpace(s string) string {
	start := 0
	for start < len(s) && (s[start] == ' ' || s[start] == '\t') {
		start++
	}
	end := len(s)
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t') {
		end--
	}
	return s[start:end]
}

func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}
