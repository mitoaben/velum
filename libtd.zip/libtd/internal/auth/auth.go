// Package auth реализует криптографическую авторизацию libtd:
//   - Proof-of-Work (challenge / SHA-256 substring)
//   - ED25519 ключи (генерация, парсинг PEM, подпись nonce при логине)
//   - Сессионные куки с записью в БД
package auth

import (
        "context"
        "crypto/ed25519"
        "crypto/hmac"
        "crypto/rand"
        "crypto/sha256"
        "crypto/x509"
        "encoding/base64"
        "encoding/hex"
        "encoding/pem"
        "errors"
        "fmt"
        "net/http"
        "strings"
        "time"

        "github.com/libtd/libtd/internal/db"
        "github.com/libtd/libtd/internal/models"
)

// PoW — генератор и валидатор Proof-of-Work задач.
//
// Алгоритм (спецификация проекта):
//   1. Бэкенд генерирует случайную строку из N символов (challenge).
//   2. Фронтенд итерирует nonce = 0, 1, 2, ... и считает SHA-256(challenge + ":" + nonce).
//   3. Если hex-хэш содержит challenge в любом месте — решение найдено.
//   4. Бэкенд перепроверяет: SHA-256(challenge + ":" + nonce) содержит challenge,
//      челлендж не протух, не использован, purpose совпадает.
//
// Длина challenge 4–5 символов даёт ~0.5–2 секунды решения на типичном браузере.
type PoW struct {
        DB           *db.DB
        ChallengeLen int
        TTL          time.Duration
}

// alphabet для challenge. ВАЖНО: только символы, которые встречаются в hex-хэше
// (0-9a-f), иначе задача никогда не решится. Мы намеренно исключили 0/O, 1/I/l,
// чтобы было легче читать, но оставили только hex-допустимые: "0123456789abcdef".
// Чтобы сохранить защиту от похожих символов, убираем 0 и 1 (легко спутать с O/l):
// остаётся "23456789abcdef".
const alphabet = "23456789abcdef"

// Generate создаёт и сохраняет новый challenge для указанной цели.
func (p *PoW) Generate(ctx context.Context, purpose string) (string, error) {
        if p.ChallengeLen < 3 || p.ChallengeLen > 6 {
                return "", fmt.Errorf("invalid ChallengeLen: %d", p.ChallengeLen)
        }
        buf := make([]byte, p.ChallengeLen)
        for i := range buf {
                var b [1]byte
                if _, err := rand.Read(b[:]); err != nil {
                        return "", err
                }
                buf[i] = alphabet[int(b[0])%len(alphabet)]
        }
        ch := string(buf)
        if err := p.DB.SaveChallenge(ctx, ch, purpose, p.TTL); err != nil {
                return "", err
        }
        return ch, nil
}

// Verify проверяет решение. На успехе атомарно помечает challenge использованным.
func (p *PoW) Verify(ctx context.Context, challenge, nonce, purpose string) (bool, error) {
        challenge = strings.ToLower(strings.TrimSpace(challenge))
        nonce = strings.TrimSpace(nonce)
        if challenge == "" || nonce == "" || len(challenge) > 16 || len(nonce) > 64 {
                return false, errors.New("invalid input")
        }
        hash := sha256.Sum256([]byte(challenge + ":" + nonce))
        hexHash := hex.EncodeToString(hash[:])
        if !strings.Contains(hexHash, challenge) {
                return false, nil
        }
        ok, err := p.DB.ConsumeChallenge(ctx, challenge, purpose)
        if err != nil {
                return false, err
        }
        return ok, nil
}

// --- ED25519 ключи ---

// Keys — обёртка над ED25519 операциями.
type Keys struct{}

// GeneratePair возвращает PEM-encoded приватный ключ и base64 публичный.
// Приватный ключ отдаётся юзеру как файл, публичный сохраняется в БД.
func (Keys) GeneratePair() (privKeyPEM string, pubKeyBase64 string, err error) {
        pub, priv, err := ed25519.GenerateKey(rand.Reader)
        if err != nil {
                return "", "", err
        }
        der, err := x509.MarshalPKCS8PrivateKey(priv)
        if err != nil {
                return "", "", err
        }
        privKeyPEM = string(pem.EncodeToMemory(&pem.Block{
                Type:  "PRIVATE KEY",
                Bytes: der,
        }))
        pubKeyBase64 = base64.StdEncoding.EncodeToString(pub)
        return privKeyPEM, pubKeyBase64, nil
}

// ParsePrivateKey парсит PEM private key в ED25519 PrivateKey.
// Поддерживает PKCS8 ("PRIVATE KEY") и PKCS1 ("EC PRIVATE KEY" / устаревший).
func (Keys) ParsePrivateKey(pemData string) (ed25519.PrivateKey, error) {
        block, _ := pem.Decode([]byte(pemData))
        if block == nil {
                return nil, errors.New("no PEM block found in private key")
        }

        var pk ed25519.PrivateKey
        switch block.Type {
        case "PRIVATE KEY":
                k, err := x509.ParsePKCS8PrivateKey(block.Bytes)
                if err != nil {
                        return nil, fmt.Errorf("parse PKCS8: %w", err)
                }
                ed, ok := k.(ed25519.PrivateKey)
                if !ok {
                        return nil, errors.New("not an ED25519 private key")
                }
                pk = ed
        default:
                return nil, fmt.Errorf("unsupported PEM block type: %s", block.Type)
        }
        if len(pk) != ed25519.PrivateKeySize {
                return nil, fmt.Errorf("invalid ed25519 private key size: %d", len(pk))
        }
        return pk, nil
}

// Sign подписывает сообщение приватным ключом.
func (Keys) Sign(priv ed25519.PrivateKey, message []byte) ([]byte, error) {
        if len(priv) != ed25519.PrivateKeySize {
                return nil, errors.New("invalid ed25519 private key size")
        }
        return ed25519.Sign(priv, message), nil
}

// VerifyPub проверяет подпись по base64-публичному ключу.
func (Keys) VerifyPub(pubBase64 string, message, sig []byte) (bool, error) {
        pub, err := base64.StdEncoding.DecodeString(pubBase64)
        if err != nil {
                return false, fmt.Errorf("decode public key: %w", err)
        }
        if len(pub) != ed25519.PublicKeySize {
                return false, errors.New("invalid ed25519 public key size")
        }
        return ed25519.Verify(pub, message, sig), nil
}

// --- Sessions ---

// SessionCookieName — имя сессионной куки.
const SessionCookieName = "libtd_session"

// Sessions — менеджер сессий. Хранит токены в БД, куку подписывает HMAC
// (доп. защита от подделки: токен в куке = base64(random32) + "." + hmac).
type Sessions struct {
        DB *db.DB
        // Key должна быть 32+ байт. Берётся из config.SessionKey.
        Key    []byte
        TTL    time.Duration
        Secure bool
}

// NewSession создаёт сессию и возвращает подписанное значение для куки.
func (s *Sessions) NewSession(ctx context.Context, userID int64) (string, error) {
        var raw [32]byte
        if _, err := rand.Read(raw[:]); err != nil {
                return "", err
        }
        token := base64.RawURLEncoding.EncodeToString(raw[:])
        if err := s.DB.CreateSession(ctx, token, userID, s.TTL); err != nil {
                return "", err
        }
        return s.signToken(token), nil
}

// ResolveFromRequest достаёт куку, проверяет подпись и возвращает юзера.
func (s *Sessions) ResolveFromRequest(ctx context.Context, r *http.Request) (*models.User, error) {
        cookie, err := r.Cookie(SessionCookieName)
        if err != nil || cookie.Value == "" {
                return nil, errNoSession
        }
        token, ok := s.verifyToken(cookie.Value)
        if !ok {
                return nil, errNoSession
        }
        return s.DB.UserBySession(ctx, token)
}

// Logout удаляет сессию из БД (куку чистит caller).
func (s *Sessions) Logout(ctx context.Context, r *http.Request) error {
        cookie, err := r.Cookie(SessionCookieName)
        if err != nil {
                return nil
        }
        token, ok := s.verifyToken(cookie.Value)
        if !ok {
                return nil
        }
        return s.DB.DeleteSession(ctx, token)
}

// SetCookie выставляет сессионную куку в ответе.
func (s *Sessions) SetCookie(w http.ResponseWriter, signed string) {
        http.SetCookie(w, &http.Cookie{
                Name:     SessionCookieName,
                Value:    signed,
                Path:     "/",
                HttpOnly: true,
                Secure:   s.Secure,
                SameSite: http.SameSiteLaxMode,
                MaxAge:   int(s.TTL.Seconds()),
        })
}

// ClearCookie — удаление куки на клиенте.
func (s *Sessions) ClearCookie(w http.ResponseWriter) {
        http.SetCookie(w, &http.Cookie{
                Name:     SessionCookieName,
                Value:    "",
                Path:     "/",
                HttpOnly: true,
                Secure:   s.Secure,
                SameSite: http.SameSiteLaxMode,
                MaxAge:   -1,
        })
}

func (s *Sessions) signToken(token string) string {
        mac := hmac.New(sha256.New, s.Key)
        mac.Write([]byte(token))
        sig := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
        return token + "." + sig
}

func (s *Sessions) verifyToken(signed string) (string, bool) {
        idx := strings.LastIndex(signed, ".")
        if idx <= 0 || idx == len(signed)-1 {
                return "", false
        }
        token := signed[:idx]
        sig := signed[idx+1:]

        mac := hmac.New(sha256.New, s.Key)
        mac.Write([]byte(token))
        expected := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
        if !hmac.Equal([]byte(sig), []byte(expected)) {
                return "", false
        }
        return token, true
}

// errNoSession возвращается, когда куки нет или она невалидна.
var errNoSession = errors.New("no session")

// IsNoSession проверяет, что ошибка — "нет сессии".
func IsNoSession(err error) bool { return errors.Is(err, errNoSession) }
