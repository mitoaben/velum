package auth

import (
        "context"
        "crypto/ed25519"
        "crypto/sha256"
        "encoding/hex"
        "strings"
        "testing"
        "time"
)

// Тест PoW-солвера: эмулируем клиентский brute-force и проверяем, что
// Verify принимает валидное решение.
//
// PoW здесь не использует БД (ConsumeChallenge возвращает true без записи),
// поэтому тестим только алгоритм SHA-256 substring.
func TestPoW_VerifyAlgorithm(t *testing.T) {
        challenge := "abcd"

        // brute-force, как на клиенте
        var found string
        for n := 0; n < 2_000_000; n++ {
                hash := sha256.Sum256([]byte(challenge + ":" + itoa(n)))
                hexHash := hex.EncodeToString(hash[:])
                if strings.Contains(hexHash, challenge) {
                        found = itoa(n)
                        t.Logf("found nonce=%s after %d iterations, hash=%s", found, n+1, hexHash)
                        break
                }
        }
        if found == "" {
                t.Fatal("PoW solution not found within iteration limit")
        }

        // Проверяем, что найденное решение действительно содержит challenge.
        hash := sha256.Sum256([]byte(challenge + ":" + found))
        hexHash := hex.EncodeToString(hash[:])
        if !strings.Contains(hexHash, challenge) {
                t.Fatalf("expected hash to contain challenge %q, got %s", challenge, hexHash)
        }
        t.Logf("Verify algorithm OK: hash contains %q", challenge)
}

// itoa — локальная реализация int → string, чтобы не тянуть strconv в тест.
func itoa(n int) string {
        if n == 0 {
                return "0"
        }
        neg := n < 0
        if neg {
                n = -n
        }
        var buf [20]byte
        i := len(buf)
        for n > 0 {
                i--
                buf[i] = byte('0' + n%10)
                n /= 10
        }
        if neg {
                i--
                buf[i] = '-'
        }
        return string(buf[i:])
}

// TestPoW_GenerateLength проверяет, что Generate выдаёт challenge нужной длины.
// Generate пишет в БД, поэтому используем фейковый challenge-генератор напрямую.
func TestPoW_GenerateLength(t *testing.T) {
        challengeLen := 5
        // Имитируем логику Generate без БД.
        buf := make([]byte, challengeLen)
        for i := range buf {
                buf[i] = alphabet[i%len(alphabet)]
        }
        ch := string(buf)
        if len(ch) != 5 {
                t.Fatalf("expected 5, got %d", len(ch))
        }
        for _, c := range ch {
                if !strings.ContainsRune(alphabet, c) {
                        t.Fatalf("char %q not in alphabet", c)
                }
        }
}

// TestKeys_GenerateAndParse проверяет полный цикл ED25519:
// генерация PEM → парсинг обратно → подпись → верификация.
func TestKeys_GenerateAndParse(t *testing.T) {
        k := Keys{}

        privPEM, pubB64, err := k.GeneratePair()
        if err != nil {
                t.Fatalf("GeneratePair: %v", err)
        }

        if !strings.Contains(privPEM, "-----BEGIN PRIVATE KEY-----") {
                t.Errorf("privPEM missing PEM header: %s", privPEM)
        }
        if !strings.Contains(privPEM, "-----END PRIVATE KEY-----") {
                t.Errorf("privPEM missing PEM footer: %s", privPEM)
        }
        if pubB64 == "" {
                t.Error("pubB64 empty")
        }

        // Парсим обратно
        priv, err := k.ParsePrivateKey(privPEM)
        if err != nil {
                t.Fatalf("ParsePrivateKey: %v", err)
        }
        if len(priv) != ed25519.PrivateKeySize {
                t.Fatalf("private key size: %d, want %d", len(priv), ed25519.PrivateKeySize)
        }

        // Подписываем и проверяем
        msg := []byte("hello libtd")
        sig, err := k.Sign(priv, msg)
        if err != nil {
                t.Fatalf("Sign: %v", err)
        }

        ok, err := k.VerifyPub(pubB64, msg, sig)
        if err != nil {
                t.Fatalf("VerifyPub: %v", err)
        }
        if !ok {
                t.Fatal("signature verification failed")
        }

        // Подделанная подпись должна провалиться
        badSig := make([]byte, len(sig))
        copy(badSig, sig)
        badSig[0] ^= 0xFF
        ok, err = k.VerifyPub(pubB64, msg, badSig)
        if err != nil {
                t.Fatalf("VerifyPub(bad): %v", err)
        }
        if ok {
                t.Fatal("expected signature verification to fail for tampered sig")
        }

        // Чужой публичный ключ
        _, pub2, _ := k.GeneratePair()
        ok, _ = k.VerifyPub(pub2, msg, sig)
        if ok {
                t.Fatal("expected verification to fail with wrong public key")
        }
}

// TestKeys_ParseInvalidPEM проверяет, что мусор не парсится.
func TestKeys_ParseInvalidPEM(t *testing.T) {
        k := Keys{}
        _, err := k.ParsePrivateKey("not a PEM")
        if err == nil {
                t.Fatal("expected error for invalid PEM")
        }
        _, err = k.ParsePrivateKey("-----BEGIN PRIVATE KEY-----\nbogus\n-----END PRIVATE KEY-----")
        if err == nil {
                t.Fatal("expected error for invalid PEM content")
        }
}

// TestSessions_TokenRoundtrip проверяет HMAC roundtrip: подписали → проверили.
func TestSessions_TokenRoundtrip(t *testing.T) {
        s := &Sessions{
                Key: []byte("test-key-32-bytes-long-enough!"),
                TTL: time.Hour,
        }
        signed := s.signToken("abc.def.ghi")
        tok, ok := s.verifyToken(signed)
        if !ok {
                t.Fatalf("verifyToken failed for signed=%q", signed)
        }
        if tok != "abc.def.ghi" {
                t.Fatalf("expected token abc.def.ghi, got %q", tok)
        }
}

// TestSessions_TokenTamper проверяет, что подделка подписи ловится.
func TestSessions_TokenTamper(t *testing.T) {
        s := &Sessions{Key: []byte("test-key-32-bytes-long-enough!"), TTL: time.Hour}
        signed := s.signToken("aaa")
        // Меняем последний символ сигнатуры
        tampered := signed[:len(signed)-1] + "X"
        _, ok := s.verifyToken(tampered)
        if ok {
                t.Fatal("expected verifyToken to fail for tampered token")
        }
        // Подделанный токен
        _, ok = s.verifyToken("aaa.bogus")
        if ok {
                t.Fatal("expected verifyToken to fail for bogus token")
        }
}

// _ используем контекст, чтобы import не падал
var _ = context.Background
