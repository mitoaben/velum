// Package config держит все настройки приложения, читаемые из env-переменных.
// Значения по умолчанию подобраны так, чтобы локальный запуск работал "из коробки".
package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

// Config — единая структура конфигурации.
type Config struct {
	// HTTP
	Addr string // адрес, на котором слушает HTTP-сервер, например ":8080"

	// PostgreSQL
	DatabaseURL string // полный DSN, например postgres://user:pass@localhost:5432/libtd?sslmode=disable

	// Сессии
	SessionKey    string        // 32+ байт, кодирует cookie-значения
	SessionTTL    time.Duration // срок жизни сессионной куки
	CookieSecure  bool          // true, если сайт на HTTPS (в проде — обязательно)

	// PoW
	PoWChallengeLen int           // длина challenge-строки (4–5)
	PoWTTL          time.Duration // срок годности challenge
	PoWDifficulty   int           // не используется для строгой сложности, но влияет на min-итерации

	// Загрузка файлов
	MaxFileSize      int64 // в байтах; читается/пишется также в БД (таблица settings)
	UploadDir        string
	AllowedMimeTypes []string // пустой список = разрешено всё в пределах MaxFileSize

	// Хранилище
	StorageKind string // "local" | "s3"

	// S3 (если StorageKind == "s3")
	S3Endpoint  string
	S3Region    string
	S3Bucket    string
	S3AccessKey string
	S3SecretKey string
	S3UsePath   bool // true для MinIO
	S3PublicURL string // базовый публичный URL, например https://cdn.libtd.com

	// Форум
	DefaultBoardSlug string // обычно "all"

	// Окружение
	Env string // "dev" | "prod"
}

// Load читает конфиг из env и возвращает готовую структуру.
func Load() (*Config, error) {
	cfg := &Config{
		Addr:             env("ADDR", ":8080"),
		DatabaseURL:      env("DATABASE_URL", "postgres://libtd:libtd@localhost:5432/libtd?sslmode=disable"),
		SessionKey:       env("SESSION_KEY", "change-me-please-32-bytes-long-!@#$"),
		SessionTTL:       envDuration("SESSION_TTL", 30*24*time.Hour),
		CookieSecure:     envBool("COOKIE_SECURE", false),
		PoWChallengeLen:  envInt("POW_CHALLENGE_LEN", 4),
		PoWTTL:           envDuration("POW_TTL", 5*time.Minute),
		PoWDifficulty:    envInt("POW_DIFFICULTY", 1),
		MaxFileSize:      envInt64("MAX_FILE_SIZE", 100*1024*1024), // 100 МБ по умолчанию
		UploadDir:        env("UPLOAD_DIR", "./uploads"),
		AllowedMimeTypes: envList("ALLOWED_MIME_TYPES", nil),
		StorageKind:      env("STORAGE_KIND", "local"),
		S3Endpoint:       env("S3_ENDPOINT", ""),
		S3Region:         env("S3_REGION", "us-east-1"),
		S3Bucket:         env("S3_BUCKET", "libtd"),
		S3AccessKey:      env("S3_ACCESS_KEY", ""),
		S3SecretKey:      env("S3_SECRET_KEY", ""),
		S3UsePath:        envBool("S3_USE_PATH", true),
		S3PublicURL:      env("S3_PUBLIC_URL", ""),
		DefaultBoardSlug: env("DEFAULT_BOARD_SLUG", "all"),
		Env:              env("APP_ENV", "dev"),
	}

	if cfg.SessionKey == "change-me-please-32-bytes-long-!@#$" && cfg.Env == "prod" {
		return nil, fmt.Errorf("SESSION_KEY must be set in production")
	}
	if cfg.PoWChallengeLen < 3 || cfg.PoWChallengeLen > 6 {
		return nil, fmt.Errorf("POW_CHALLENGE_LEN must be 3..6, got %d", cfg.PoWChallengeLen)
	}
	return cfg, nil
}

// --- helpers ---

func env(key, def string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return def
}

func envBool(key string, def bool) bool {
	if v, ok := os.LookupEnv(key); ok {
		b, err := strconv.ParseBool(v)
		if err == nil {
			return b
		}
	}
	return def
}

func envInt(key string, def int) int {
	if v, ok := os.LookupEnv(key); ok {
		i, err := strconv.Atoi(v)
		if err == nil {
			return i
		}
	}
	return def
}

func envInt64(key string, def int64) int64 {
	if v, ok := os.LookupEnv(key); ok {
		i, err := strconv.ParseInt(v, 10, 64)
		if err == nil {
			return i
		}
	}
	return def
}

func envDuration(key string, def time.Duration) time.Duration {
	if v, ok := os.LookupEnv(key); ok {
		d, err := time.ParseDuration(v)
		if err == nil {
			return d
		}
	}
	return def
}

func envList(key string, def []string) []string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		parts := strings.Split(v, ",")
		out := make([]string, 0, len(parts))
		for _, p := range parts {
			if t := strings.TrimSpace(p); t != "" {
				out = append(out, t)
			}
		}
		return out
	}
	return def
}
