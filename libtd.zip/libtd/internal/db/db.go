// Package db — обёртка над pgx для libtd.
// Хранит *pgxpool.Pool и предоставляет методы-репозитории,
// чтобы хендлеры не зависели от SQL напрямую.
package db

import (
        "context"
        "embed"
        "errors"
        "fmt"
        "time"

        "github.com/jackc/pgx/v5"
        "github.com/jackc/pgx/v5/pgconn"
        "github.com/jackc/pgx/v5/pgxpool"
)

//go:embed migrations/*.sql
var migrationsFS embed.FS

// DB — фасад над пулом соединений.
type DB struct {
        Pool *pgxpool.Pool
}

// Open открывает пул к Postgres, прогоняет миграции и возвращает DB.
func Open(ctx context.Context, databaseURL string) (*DB, error) {
        pool, err := pgxpool.New(ctx, databaseURL)
        if err != nil {
                return nil, fmt.Errorf("pgxpool.New: %w", err)
        }

        if err := pool.Ping(ctx); err != nil {
                pool.Close()
                return nil, fmt.Errorf("ping db: %w", err)
        }

        db := &DB{Pool: pool}
        if err := db.Migrate(ctx); err != nil {
                pool.Close()
                return nil, fmt.Errorf("migrate: %w", err)
        }
        return db, nil
}

// Close — закрывает пул.
func (db *DB) Close() {
        if db.Pool != nil {
                db.Pool.Close()
        }
}

// Migrate применяет встроенные SQL-файлы из internal/db/migrations/.
// Идемпотентно: SQL-файлы уже содержат CREATE TABLE IF NOT EXISTS.
func (db *DB) Migrate(ctx context.Context) error {
        entries, err := migrationsFS.ReadDir("migrations")
        if err != nil {
                return fmt.Errorf("read migrations dir: %w", err)
        }
        for _, e := range entries {
                if e.IsDir() {
                        continue
                }
                sql, err := migrationsFS.ReadFile("migrations/" + e.Name())
                if err != nil {
                        return fmt.Errorf("read migration %s: %w", e.Name(), err)
                }
                if _, err := db.Pool.Exec(ctx, string(sql)); err != nil {
                        return fmt.Errorf("exec migration %s: %w", e.Name(), err)
                }
        }
        return nil
}

// --- helpers ---

// ErrNotFound возвращается хранилищем, когда строк нет.
var ErrNotFound = pgx.ErrNoRows

// IsUniqueViolation проверяет, является ли ошибка нарушением UNIQUE-ограничения.
func IsUniqueViolation(err error) bool {
        var pgErr *pgconn.PgError
        if errors.As(err, &pgErr) {
                return pgErr.Code == "23505"
        }
        return false
}

// CleanupExpiredChallenges удаляет протухшие PoW-челленджи и старые сессии.
// Вызывается по таймеру из main.go.
func (db *DB) CleanupExpiredChallenges(ctx context.Context) error {
        now := time.Now()
        _, err := db.Pool.Exec(ctx,
                `DELETE FROM pow_challenges WHERE expires_at < $1 OR used = TRUE`, now)
        if err != nil {
                return err
        }
        _, err = db.Pool.Exec(ctx,
                `DELETE FROM sessions WHERE expires_at < $1`, now)
        return err
}
