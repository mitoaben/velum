-- 001_init.sql — начальная схема БД libtd.
-- Запускается автоматически при старте сервера (см. internal/db/migrations.go).

CREATE TABLE IF NOT EXISTS users (
    id              BIGSERIAL PRIMARY KEY,
    nickname        TEXT NOT NULL UNIQUE,
    public_key      TEXT NOT NULL,                 -- PEM-encoded ED25519 public key (base64)
    is_super_admin  BOOLEAN NOT NULL DEFAULT FALSE,
    is_moderator    BOOLEAN NOT NULL DEFAULT FALSE, -- глобальный флаг; модераторство по доске — в board_moderators
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS boards (
    id           BIGSERIAL PRIMARY KEY,
    slug         TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    description  TEXT NOT NULL DEFAULT '',
    creator_id   BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Какими досками управляет юзер (модераторы).
CREATE TABLE IF NOT EXISTS board_moderators (
    board_id BIGINT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
    user_id  BIGINT NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
    PRIMARY KEY (board_id, user_id)
);

CREATE TABLE IF NOT EXISTS threads (
    id          BIGSERIAL PRIMARY KEY,
    board_id    BIGINT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
    author_id   BIGINT NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    title       TEXT NOT NULL,
    content     TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_threads_board_created ON threads (board_id, created_at DESC);

CREATE TABLE IF NOT EXISTS replies (
    id           BIGSERIAL PRIMARY KEY,
    thread_id    BIGINT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    author_id    BIGINT NOT NULL REFERENCES users(id)  ON DELETE SET NULL,
    content      TEXT NOT NULL,
    reply_to_id  BIGINT REFERENCES replies(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_replies_thread ON replies (thread_id, created_at);

CREATE TABLE IF NOT EXISTS attachments (
    id         BIGSERIAL PRIMARY KEY,
    rel_id     BIGINT NOT NULL,            -- ID треда или ответа
    rel_type   TEXT NOT NULL CHECK (rel_type IN ('thread','reply')),
    file_path  TEXT NOT NULL,              -- путь внутри FileStorage (ключ объекта)
    file_name  TEXT NOT NULL,              -- оригинальное имя файла
    file_size  BIGINT NOT NULL DEFAULT 0,
    mime_type  TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_attachments_rel ON attachments (rel_type, rel_id);

CREATE TABLE IF NOT EXISTS board_suggestions (
    id         BIGSERIAL PRIMARY KEY,
    author_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    name       TEXT NOT NULL,
    votes      INTEGER NOT NULL DEFAULT 0,
    status     TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','approved','rejected')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS suggestion_votes (
    user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    suggestion_id BIGINT NOT NULL REFERENCES board_suggestions(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, suggestion_id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
    user_id  BIGINT NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
    board_id BIGINT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, board_id)
);

CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT PRIMARY KEY,            -- криптостойкий случайный токен
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions (expires_at);

CREATE TABLE IF NOT EXISTS pow_challenges (
    challenge TEXT PRIMARY KEY,
    purpose   TEXT NOT NULL,                -- 'register' | 'login'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    used      BOOLEAN NOT NULL DEFAULT FALSE
);

-- Глобальные настройки сайта (key/value). Например: max_file_size, site_name.
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Доска по умолчанию "all" без автора (creator_id = NULL).
-- Первый зарегистрированный юзер станет супер-админом (обрабатывается в коде),
-- но доске 'all' он не "принадлежит".
INSERT INTO boards (slug, name, description, creator_id)
SELECT 'all', 'All', 'Общая доска по умолчанию. Здесь можно создавать треды на любые темы.', NULL
WHERE NOT EXISTS (SELECT 1 FROM boards WHERE slug = 'all');

-- Дефолтный лимит загрузки (100 МБ), если в env не задано иное. Можно перезаписать из админки.
INSERT INTO settings (key, value)
SELECT 'max_file_size', '104857600'
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE key = 'max_file_size');
