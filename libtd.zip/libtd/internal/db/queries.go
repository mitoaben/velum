package db

import (
        "context"
        "errors"
        "time"

        "github.com/libtd/libtd/internal/models"
)

// --- Users ---

// CreateUser создаёт пользователя и возвращает его. Если это первый юзер в БД —
// ему автоматически ставится is_super_admin = TRUE.
func (db *DB) CreateUser(ctx context.Context, nickname, publicKey string) (*models.User, error) {
        var u models.User
        err := db.Pool.QueryRow(ctx, `
                WITH cnt AS (SELECT COUNT(*) AS n FROM users)
                INSERT INTO users (nickname, public_key, is_super_admin)
                SELECT $1, $2, (cnt.n = 0) FROM cnt
                RETURNING id, nickname, public_key, is_super_admin, is_moderator, created_at`,
                nickname, publicKey,
        ).Scan(&u.ID, &u.Nickname, &u.PublicKey, &u.IsSuperAdmin, &u.IsModerator, &u.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &u, nil
}

// UserByNickname ищет юзера по нику.
func (db *DB) UserByNickname(ctx context.Context, nickname string) (*models.User, error) {
        var u models.User
        err := db.Pool.QueryRow(ctx, `
                SELECT id, nickname, public_key, is_super_admin, is_moderator, created_at
                FROM users WHERE nickname = $1`, nickname,
        ).Scan(&u.ID, &u.Nickname, &u.PublicKey, &u.IsSuperAdmin, &u.IsModerator, &u.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &u, nil
}

// UserByID ищет юзера по ID.
func (db *DB) UserByID(ctx context.Context, id int64) (*models.User, error) {
        var u models.User
        err := db.Pool.QueryRow(ctx, `
                SELECT id, nickname, public_key, is_super_admin, is_moderator, created_at
                FROM users WHERE id = $1`, id,
        ).Scan(&u.ID, &u.Nickname, &u.PublicKey, &u.IsSuperAdmin, &u.IsModerator, &u.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &u, nil
}

// ListUsers возвращает всех юзеров (для админки).
func (db *DB) ListUsers(ctx context.Context) ([]models.User, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT id, nickname, public_key, is_super_admin, is_moderator, created_at
                FROM users ORDER BY id ASC`)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.User
        for rows.Next() {
                var u models.User
                if err := rows.Scan(&u.ID, &u.Nickname, &u.PublicKey, &u.IsSuperAdmin, &u.IsModerator, &u.CreatedAt); err != nil {
                        return nil, err
                }
                out = append(out, u)
        }
        return out, rows.Err()
}

// DeleteUser удаляет юзера. Супер-админа удалить нельзя (защита в handler).
func (db *DB) DeleteUser(ctx context.Context, id int64) error {
        tag, err := db.Pool.Exec(ctx, `DELETE FROM users WHERE id = $1 AND NOT is_super_admin`, id)
        if err != nil {
                return err
        }
        if tag.RowsAffected() == 0 {
                return errors.New("user not found or is super admin")
        }
        return nil
}

// SetUserRole выставляет роли is_moderator / is_super_admin.
// Супер-админ не может снять флаг сам у себя (защита в handler).
func (db *DB) SetUserRole(ctx context.Context, id int64, isMod bool) error {
        _, err := db.Pool.Exec(ctx,
                `UPDATE users SET is_moderator = $1 WHERE id = $2 AND NOT is_super_admin`, isMod, id)
        return err
}

// --- Sessions ---

// CreateSession вставляет новую сессию.
func (db *DB) CreateSession(ctx context.Context, token string, userID int64, ttl time.Duration) error {
        _, err := db.Pool.Exec(ctx,
                `INSERT INTO sessions (token, user_id, expires_at) VALUES ($1, $2, NOW() + $3)`,
                token, userID, ttl)
        return err
}

// UserBySession возвращает юзера по токену сессии, если она не протухла.
func (db *DB) UserBySession(ctx context.Context, token string) (*models.User, error) {
        var u models.User
        err := db.Pool.QueryRow(ctx, `
                SELECT u.id, u.nickname, u.public_key, u.is_super_admin, u.is_moderator, u.created_at
                FROM sessions s
                JOIN users u ON u.id = s.user_id
                WHERE s.token = $1 AND s.expires_at > NOW()`, token,
        ).Scan(&u.ID, &u.Nickname, &u.PublicKey, &u.IsSuperAdmin, &u.IsModerator, &u.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &u, nil
}

// DeleteSession удаляет конкретную сессию (logout).
func (db *DB) DeleteSession(ctx context.Context, token string) error {
        _, err := db.Pool.Exec(ctx, `DELETE FROM sessions WHERE token = $1`, token)
        return err
}

// --- PoW challenges ---

// SaveChallenge сохраняет новый PoW-челлендж.
func (db *DB) SaveChallenge(ctx context.Context, challenge, purpose string, ttl time.Duration) error {
        _, err := db.Pool.Exec(ctx,
                `INSERT INTO pow_challenges (challenge, purpose, expires_at) VALUES ($1, $2, NOW() + $3)
                 ON CONFLICT (challenge) DO NOTHING`,
                challenge, purpose, ttl)
        return err
}

// ConsumeChallenge помечает челлендж использованным. Возвращает true, если это удалось.
// Атомарно: один челлендж = одно использование.
func (db *DB) ConsumeChallenge(ctx context.Context, challenge, purpose string) (bool, error) {
        tag, err := db.Pool.Exec(ctx, `
                UPDATE pow_challenges
                SET used = TRUE
                WHERE challenge = $1 AND purpose = $2 AND used = FALSE AND expires_at > NOW()`,
                challenge, purpose)
        if err != nil {
                return false, err
        }
        return tag.RowsAffected() > 0, nil
}

// --- Boards ---

// BoardBySlug ищет доску по slug.
func (db *DB) BoardBySlug(ctx context.Context, slug string) (*models.Board, error) {
        var b models.Board
        err := db.Pool.QueryRow(ctx, `
                SELECT id, slug, name, description, COALESCE(creator_id, 0), created_at
                FROM boards WHERE slug = $1`, slug,
        ).Scan(&b.ID, &b.Slug, &b.Name, &b.Description, &b.CreatorID, &b.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &b, nil
}

// CreateBoard создаёт доску.
func (db *DB) CreateBoard(ctx context.Context, slug, name, description string, creatorID int64) (*models.Board, error) {
        var b models.Board
        err := db.Pool.QueryRow(ctx, `
                INSERT INTO boards (slug, name, description, creator_id)
                VALUES ($1, $2, $3, NULLIF($4, 0))
                RETURNING id, slug, name, description, COALESCE(creator_id, 0), created_at`,
                slug, name, description, creatorID,
        ).Scan(&b.ID, &b.Slug, &b.Name, &b.Description, &b.CreatorID, &b.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &b, nil
}

// ListBoards возвращает все доски.
func (db *DB) ListBoards(ctx context.Context) ([]models.Board, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT id, slug, name, description, COALESCE(creator_id, 0), created_at
                FROM boards ORDER BY id ASC`)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.Board
        for rows.Next() {
                var b models.Board
                if err := rows.Scan(&b.ID, &b.Slug, &b.Name, &b.Description, &b.CreatorID, &b.CreatedAt); err != nil {
                        return nil, err
                }
                out = append(out, b)
        }
        return out, rows.Err()
}

// ListSubscribedBoards — доски, на которые подписан юзер.
func (db *DB) ListSubscribedBoards(ctx context.Context, userID int64) ([]models.Board, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT b.id, b.slug, b.name, b.description, COALESCE(b.creator_id, 0), b.created_at
                FROM subscriptions s
                JOIN boards b ON b.id = s.board_id
                WHERE s.user_id = $1
                ORDER BY b.id ASC`, userID)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.Board
        for rows.Next() {
                var b models.Board
                if err := rows.Scan(&b.ID, &b.Slug, &b.Name, &b.Description, &b.CreatorID, &b.CreatedAt); err != nil {
                        return nil, err
                }
                out = append(out, b)
        }
        return out, rows.Err()
}

// Subscribe / Unsubscribe — управление подписками.
func (db *DB) Subscribe(ctx context.Context, userID, boardID int64) error {
        _, err := db.Pool.Exec(ctx,
                `INSERT INTO subscriptions (user_id, board_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                userID, boardID)
        return err
}

func (db *DB) Unsubscribe(ctx context.Context, userID, boardID int64) error {
        _, err := db.Pool.Exec(ctx,
                `DELETE FROM subscriptions WHERE user_id = $1 AND board_id = $2`, userID, boardID)
        return err
}

// IsModerator проверяет, модератор ли юзер конкретной доски.
func (db *DB) IsModerator(ctx context.Context, userID, boardID int64) (bool, error) {
        var ok bool
        err := db.Pool.QueryRow(ctx,
                `SELECT EXISTS(SELECT 1 FROM board_moderators WHERE user_id = $1 AND board_id = $2)`,
                userID, boardID).Scan(&ok)
        return ok, err
}

// AddModerator добавляет модератора доске.
func (db *DB) AddModerator(ctx context.Context, userID, boardID int64) error {
        _, err := db.Pool.Exec(ctx,
                `INSERT INTO board_moderators (user_id, board_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                userID, boardID)
        return err
}

// --- Threads ---

// CreateThread создаёт тред и возвращает его.
func (db *DB) CreateThread(ctx context.Context, boardID, authorID int64, title, content string) (*models.Thread, error) {
        var t models.Thread
        err := db.Pool.QueryRow(ctx, `
                INSERT INTO threads (board_id, author_id, title, content)
                VALUES ($1, $2, $3, $4)
                RETURNING id, board_id, author_id, title, content, created_at`,
                boardID, authorID, title, content,
        ).Scan(&t.ID, &t.BoardID, &t.AuthorID, &t.Title, &t.Content, &t.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &t, nil
}

// ThreadByID — одна запись треда.
func (db *DB) ThreadByID(ctx context.Context, id int64) (*models.Thread, error) {
        var t models.Thread
        err := db.Pool.QueryRow(ctx, `
                SELECT t.id, t.board_id, t.author_id,
                       COALESCE(u.nickname, 'deleted'),
                       t.title, t.content, t.created_at,
                       (SELECT COUNT(*) FROM replies r WHERE r.thread_id = t.id)
                FROM threads t
                LEFT JOIN users u ON u.id = t.author_id
                WHERE t.id = $1`, id,
        ).Scan(&t.ID, &t.BoardID, &t.AuthorID, &t.AuthorNick, &t.Title, &t.Content, &t.CreatedAt, &t.ReplyCount)
        if err != nil {
                return nil, err
        }
        return &t, nil
}

// ListThreadsByBoard — последние N тредов доски (с пагинацией).
func (db *DB) ListThreadsByBoard(ctx context.Context, boardID int64, limit, offset int) ([]models.Thread, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT t.id, t.board_id, t.author_id,
                       COALESCE(u.nickname, 'deleted'),
                       t.title, t.content, t.created_at,
                       (SELECT COUNT(*) FROM replies r WHERE r.thread_id = t.id)
                FROM threads t
                LEFT JOIN users u ON u.id = t.author_id
                WHERE t.board_id = $1
                ORDER BY t.created_at DESC
                LIMIT $2 OFFSET $3`, boardID, limit, offset)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.Thread
        for rows.Next() {
                var t models.Thread
                if err := rows.Scan(&t.ID, &t.BoardID, &t.AuthorID, &t.AuthorNick, &t.Title, &t.Content, &t.CreatedAt, &t.ReplyCount); err != nil {
                        return nil, err
                }
                out = append(out, t)
        }
        return out, rows.Err()
}

// DeleteThread удаляет тред.
func (db *DB) DeleteThread(ctx context.Context, id int64) error {
        _, err := db.Pool.Exec(ctx, `DELETE FROM threads WHERE id = $1`, id)
        return err
}

// --- Replies ---

// CreateReply — создание ответа (возможно, на другой ответ).
func (db *DB) CreateReply(ctx context.Context, threadID, authorID int64, content string, replyToID *int64) (*models.Reply, error) {
        var r models.Reply
        err := db.Pool.QueryRow(ctx, `
                INSERT INTO replies (thread_id, author_id, content, reply_to_id)
                VALUES ($1, $2, $3, $4)
                RETURNING id, thread_id, author_id, content, reply_to_id, created_at`,
                threadID, authorID, content, replyToID,
        ).Scan(&r.ID, &r.ThreadID, &r.AuthorID, &r.Content, &r.ReplyToID, &r.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &r, nil
}

// ListRepliesByThread — плоский список ответов треда, отсортированный по времени.
// Сервисный слой превратит его в дерево.
func (db *DB) ListRepliesByThread(ctx context.Context, threadID int64) ([]models.Reply, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT r.id, r.thread_id, r.author_id,
                       COALESCE(u.nickname, 'deleted'),
                       r.content, r.reply_to_id, r.created_at
                FROM replies r
                LEFT JOIN users u ON u.id = r.author_id
                WHERE r.thread_id = $1
                ORDER BY r.created_at ASC`, threadID)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.Reply
        for rows.Next() {
                var r models.Reply
                if err := rows.Scan(&r.ID, &r.ThreadID, &r.AuthorID, &r.AuthorNick, &r.Content, &r.ReplyToID, &r.CreatedAt); err != nil {
                        return nil, err
                }
                out = append(out, r)
        }
        return out, rows.Err()
}

// ReplyByID — один ответ.
func (db *DB) ReplyByID(ctx context.Context, id int64) (*models.Reply, error) {
        var r models.Reply
        err := db.Pool.QueryRow(ctx, `
                SELECT r.id, r.thread_id, r.author_id,
                       COALESCE(u.nickname, 'deleted'),
                       r.content, r.reply_to_id, r.created_at
                FROM replies r
                LEFT JOIN users u ON u.id = r.author_id
                WHERE r.id = $1`, id,
        ).Scan(&r.ID, &r.ThreadID, &r.AuthorID, &r.AuthorNick, &r.Content, &r.ReplyToID, &r.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &r, nil
}

// DeleteReply удаляет ответ (каскадно дочерние не трогает — они остаются с reply_to_id=NULL).
func (db *DB) DeleteReply(ctx context.Context, id int64) error {
        _, err := db.Pool.Exec(ctx, `DELETE FROM replies WHERE id = $1`, id)
        return err
}

// --- Attachments ---

// AddAttachment — сохраняет запись о файле.
func (db *DB) AddAttachment(ctx context.Context, relType string, relID int64, filePath, fileName string, fileSize int64, mimeType string) error {
        _, err := db.Pool.Exec(ctx, `
                INSERT INTO attachments (rel_id, rel_type, file_path, file_name, file_size, mime_type)
                VALUES ($1, $2, $3, $4, $5, $6)`,
                relID, relType, filePath, fileName, fileSize, mimeType)
        return err
}

// AttachmentsFor — все вложения треда или ответа.
func (db *DB) AttachmentsFor(ctx context.Context, relType string, relID int64) ([]models.Attachment, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT id, rel_id, rel_type, file_path, file_name, file_size, mime_type, created_at
                FROM attachments
                WHERE rel_type = $1 AND rel_id = $2
                ORDER BY id ASC`, relType, relID)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.Attachment
        for rows.Next() {
                var a models.Attachment
                if err := rows.Scan(&a.ID, &a.RelID, &a.RelType, &a.FilePath, &a.FileName, &a.FileSize, &a.MimeType, &a.CreatedAt); err != nil {
                        return nil, err
                }
                out = append(out, a)
        }
        return out, rows.Err()
}

// DeleteAttachmentsFor — удаляет все вложения объекта (при удалении треда/ответа).
func (db *DB) DeleteAttachmentsFor(ctx context.Context, relType string, relID int64) error {
        _, err := db.Pool.Exec(ctx,
                `DELETE FROM attachments WHERE rel_type = $1 AND rel_id = $2`, relType, relID)
        return err
}

// --- Suggestions ---

// CreateSuggestion — новое предложение доски.
func (db *DB) CreateSuggestion(ctx context.Context, authorID int64, name string) (*models.BoardSuggestion, error) {
        var s models.BoardSuggestion
        err := db.Pool.QueryRow(ctx, `
                INSERT INTO board_suggestions (author_id, name)
                VALUES ($1, $2)
                RETURNING id, author_id, name, votes, status, created_at`,
                authorID, name,
        ).Scan(&s.ID, &s.AuthorID, &s.Name, &s.Votes, &s.Status, &s.CreatedAt)
        if err != nil {
                return nil, err
        }
        return &s, nil
}

// ListSuggestions — все открытые + недавно одобренные.
func (db *DB) ListSuggestions(ctx context.Context, userID int64) ([]models.BoardSuggestion, error) {
        rows, err := db.Pool.Query(ctx, `
                SELECT s.id, s.author_id, COALESCE(u.nickname,'deleted'),
                       s.name, s.votes, s.status, s.created_at,
                       EXISTS(SELECT 1 FROM suggestion_votes v WHERE v.user_id = $1 AND v.suggestion_id = s.id) AS voted
                FROM board_suggestions s
                LEFT JOIN users u ON u.id = s.author_id
                ORDER BY s.votes DESC, s.created_at DESC`, userID)
        if err != nil {
                return nil, err
        }
        defer rows.Close()
        var out []models.BoardSuggestion
        for rows.Next() {
                var s models.BoardSuggestion
                if err := rows.Scan(&s.ID, &s.AuthorID, &s.AuthorNick, &s.Name, &s.Votes, &s.Status, &s.CreatedAt, &s.Voted); err != nil {
                        return nil, err
                }
                out = append(out, s)
        }
        return out, rows.Err()
}

// VoteSuggestion — голосование. Транзакция: вставляем голос + инкремент votes.
func (db *DB) VoteSuggestion(ctx context.Context, userID, suggestionID int64) error {
        tx, err := db.Pool.Begin(ctx)
        if err != nil {
                return err
        }
        defer tx.Rollback(ctx)

        _, err = tx.Exec(ctx,
                `INSERT INTO suggestion_votes (user_id, suggestion_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                userID, suggestionID)
        if err != nil {
                return err
        }
        _, err = tx.Exec(ctx,
                `UPDATE board_suggestions SET votes = votes + 1 WHERE id = $1`,
                suggestionID)
        if err != nil {
                return err
        }
        return tx.Commit(ctx)
}

// UnvoteSuggestion — снять голос (если решите добавить кнопку "снять голос").
func (db *DB) UnvoteSuggestion(ctx context.Context, userID, suggestionID int64) error {
        tx, err := db.Pool.Begin(ctx)
        if err != nil {
                return err
        }
        defer tx.Rollback(ctx)

        tag, err := tx.Exec(ctx,
                `DELETE FROM suggestion_votes WHERE user_id = $1 AND suggestion_id = $2`,
                userID, suggestionID)
        if err != nil {
                return err
        }
        if tag.RowsAffected() > 0 {
                _, err = tx.Exec(ctx,
                        `UPDATE board_suggestions SET votes = GREATEST(votes - 1, 0) WHERE id = $1`,
                        suggestionID)
                if err != nil {
                        return err
                }
        }
        return tx.Commit(ctx)
}

// ApproveSuggestion — помечает предложение одобренным.
func (db *DB) ApproveSuggestion(ctx context.Context, suggestionID int64) error {
        _, err := db.Pool.Exec(ctx,
                `UPDATE board_suggestions SET status = 'approved' WHERE id = $1`, suggestionID)
        return err
}

// SuggestionByID — одна запись.
func (db *DB) SuggestionByID(ctx context.Context, id int64) (*models.BoardSuggestion, error) {
        var s models.BoardSuggestion
        err := db.Pool.QueryRow(ctx, `
                SELECT s.id, s.author_id, COALESCE(u.nickname,'deleted'),
                       s.name, s.votes, s.status, s.created_at, FALSE
                FROM board_suggestions s
                LEFT JOIN users u ON u.id = s.author_id
                WHERE s.id = $1`, id,
        ).Scan(&s.ID, &s.AuthorID, &s.AuthorNick, &s.Name, &s.Votes, &s.Status, &s.CreatedAt, &s.Voted)
        if err != nil {
                return nil, err
        }
        return &s, nil
}

// --- Settings (key/value) ---

// GetSetting возвращает значение настройки или пустую строку, если её нет.
func (db *DB) GetSetting(ctx context.Context, key string) (string, error) {
        var v string
        err := db.Pool.QueryRow(ctx, `SELECT value FROM settings WHERE key = $1`, key).Scan(&v)
        if err != nil {
                return "", err
        }
        return v, nil
}

// SetSetting вставляет или обновляет настройку.
func (db *DB) SetSetting(ctx context.Context, key, value string) error {
        _, err := db.Pool.Exec(ctx,
                `INSERT INTO settings (key, value) VALUES ($1, $2)
                 ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`, key, value)
        return err
}
