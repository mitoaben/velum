package handlers

import (
	"errors"
	"net/http"
	"regexp"
	"strconv"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/libtd/libtd/internal/db"
)

// AdminPage — GET /admin. Дашборд: статистика, юзеры, предложения, настройки.
func (h *Handlers) AdminPage(w http.ResponseWriter, r *http.Request) {
	users, _ := h.DB.ListUsers(r.Context())
	boards, _ := h.DB.ListBoards(r.Context())

	admin := h.currentUser(r)
	suggestions, _ := h.DB.ListSuggestions(r.Context(), admin.ID)

	h.renderPage(w, r, "pages/admin.html", "Admin", "admin", map[string]any{
		"users":       users,
		"boards":      boards,
		"suggestions": suggestions,
		"maxFileSize": h.maxFileSize(r),
		"stats": map[string]any{
			"users":       len(users),
			"boards":      len(boards),
			"suggestions": len(suggestions),
		},
	})
}

// AdminSetMaxFileSize — POST /admin/settings/max-file-size.
// form: value (bytes)
func (h *Handlers) AdminSetMaxFileSize(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		h.safeError(w, "invalid form", http.StatusBadRequest)
		return
	}
	v := strings.TrimSpace(r.FormValue("value"))
	n, err := strconv.ParseInt(v, 10, 64)
	if err != nil || n < 1024 || n > 1024*1024*1024 {
		h.safeError(w, "value must be between 1KB and 1GB", http.StatusBadRequest)
		return
	}
	if err := h.DB.SetSetting(r.Context(), "max_file_size", strconv.FormatInt(n, 10)); err != nil {
		h.safeError(w, "save setting: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.flashSuccess(w, r, "Max file size updated")
	http.Redirect(w, r, "/admin", http.StatusSeeOther)
}

// AdminSetUserRole — POST /admin/users/{id}/role.
// form: role = "moderator" | "user"
func (h *Handlers) AdminSetUserRole(w http.ResponseWriter, r *http.Request) {
	id, err := parseInt64(chi.URLParam(r, "id"))
	if err != nil {
		h.safeError(w, "bad id", http.StatusBadRequest)
		return
	}
	if err := r.ParseForm(); err != nil {
		h.safeError(w, "invalid form", http.StatusBadRequest)
		return
	}
	role := strings.TrimSpace(r.FormValue("role"))
	isMod := role == "moderator"
	target, err := h.DB.UserByID(r.Context(), id)
	if err != nil {
		h.safeError(w, "user not found", http.StatusNotFound)
		return
	}
	if target.IsSuperAdmin {
		h.safeError(w, "cannot change super admin role", http.StatusForbidden)
		return
	}
	if err := h.DB.SetUserRole(r.Context(), id, isMod); err != nil {
		h.safeError(w, "update role: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.flashSuccess(w, r, "Role updated")
	http.Redirect(w, r, "/admin", http.StatusSeeOther)
}

// AdminDeleteUser — DELETE /admin/users/{id}.
func (h *Handlers) AdminDeleteUser(w http.ResponseWriter, r *http.Request) {
	id, err := parseInt64(chi.URLParam(r, "id"))
	if err != nil {
		h.safeError(w, "bad id", http.StatusBadRequest)
		return
	}
	target, err := h.DB.UserByID(r.Context(), id)
	if err != nil {
		h.safeError(w, "user not found", http.StatusNotFound)
		return
	}
	if target.IsSuperAdmin {
		h.safeError(w, "cannot delete super admin", http.StatusForbidden)
		return
	}
	if err := h.DB.DeleteUser(r.Context(), id); err != nil {
		h.safeError(w, "delete user: "+err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// AdminDeleteReply — DELETE /admin/replies/{id}.
// Супер-админ может удалить любой ответ.
func (h *Handlers) AdminDeleteReply(w http.ResponseWriter, r *http.Request) {
	id, err := parseInt64(chi.URLParam(r, "id"))
	if err != nil {
		h.safeError(w, "bad id", http.StatusBadRequest)
		return
	}
	atts, _ := h.DB.AttachmentsFor(r.Context(), "reply", id)
	for _, a := range atts {
		_ = h.Storage.Delete(r.Context(), a.FilePath)
	}
	_ = h.DB.DeleteAttachmentsFor(r.Context(), "reply", id)
	if err := h.DB.DeleteReply(r.Context(), id); err != nil {
		h.safeError(w, "delete reply: "+err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// AdminApproveSuggestion — POST /admin/suggestions/{id}/approve.
// Создаёт новую доску из предложения и назначает автора модератором.
func (h *Handlers) AdminApproveSuggestion(w http.ResponseWriter, r *http.Request) {
	id, err := parseInt64(chi.URLParam(r, "id"))
	if err != nil {
		h.safeError(w, "bad id", http.StatusBadRequest)
		return
	}
	s, err := h.DB.SuggestionByID(r.Context(), id)
	if err != nil {
		h.safeError(w, "suggestion not found", http.StatusNotFound)
		return
	}
	if s.Status != "open" {
		h.safeError(w, "suggestion already processed", http.StatusBadRequest)
		return
	}

	slug := slugify(s.Name)
	if slug == "" {
		slug = "board-" + strconv.FormatInt(s.ID, 10)
	}
	// Проверяем уникальность slug
	if existing, err := h.DB.BoardBySlug(r.Context(), slug); err == nil && existing != nil {
		slug = slug + "-" + strconv.FormatInt(s.ID, 10)
	}

	board, err := h.DB.CreateBoard(r.Context(), slug, s.Name, "Created from community suggestion.", s.AuthorID)
	if err != nil {
		h.safeError(w, "create board: "+err.Error(), http.StatusInternalServerError)
		return
	}
	if err := h.DB.AddModerator(r.Context(), s.AuthorID, board.ID); err != nil {
		// не блокируем — доска создана
		_ = err
	}
	if err := h.DB.ApproveSuggestion(r.Context(), id); err != nil {
		h.safeError(w, "approve suggestion: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.flashSuccess(w, r, "Board '"+s.Name+"' created and author promoted to moderator")
	http.Redirect(w, r, "/admin", http.StatusSeeOther)
}

// AdminCreateBoard — POST /admin/boards. Ручное создание доски.
// form: name, description (slug генерится из name)
func (h *Handlers) AdminCreateBoard(w http.ResponseWriter, r *http.Request) {
	admin := h.currentUser(r)
	if err := r.ParseForm(); err != nil {
		h.safeError(w, "invalid form", http.StatusBadRequest)
		return
	}
	name := strings.TrimSpace(r.FormValue("name"))
	desc := strings.TrimSpace(r.FormValue("description"))
	if len(name) < 2 || len(name) > 32 {
		h.safeError(w, "name 2..32 chars", http.StatusBadRequest)
		return
	}
	slug := slugify(name)
	if slug == "" {
		slug = "board"
	}
	if _, err := h.DB.BoardBySlug(r.Context(), slug); err == nil {
		h.safeError(w, "board with this slug already exists", http.StatusBadRequest)
		return
	}
	if _, err := h.DB.CreateBoard(r.Context(), slug, name, desc, admin.ID); err != nil {
		h.safeError(w, "create board: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.flashSuccess(w, r, "Board created")
	http.Redirect(w, r, "/admin", http.StatusSeeOther)
}

// slugify превращает имя в slug: lowercase, [a-z0-9-], без повторных '-'.
var slugRe = regexp.MustCompile(`[^a-z0-9]+`)

func slugify(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	s = slugRe.ReplaceAllString(s, "-")
	s = strings.Trim(s, "-")
	if len(s) > 32 {
		s = s[:32]
	}
	return s
}

// stub для подавления unused импорта
var _ = errors.New
var _ = db.ErrNotFound
