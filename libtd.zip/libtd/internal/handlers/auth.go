package handlers

import (
	"crypto/rand"
	"errors"
	"net/http"
	"strings"

	"github.com/libtd/libtd/internal/db"
)

// --- Register ---

// RegisterPage — GET /register.
func (h *Handlers) RegisterPage(w http.ResponseWriter, r *http.Request) {
	if h.currentUser(r) != nil {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}
	errMsg, _ := h.readFlash(w, r)
	h.renderPage(w, r, "pages/register.html", "Register", "",
		map[string]any{"flash_error": errMsg})
}

// RegisterSubmit — POST /register.
//
// Параметры формы:
//   - nickname
//   - pow_challenge
//   - pow_nonce
//
// На успехе: генерируем пару ED25519 ключей, создаём юзера, отдаём страницу
// с приватным ключом для скачивания и автоматический логин.
func (h *Handlers) RegisterSubmit(w http.ResponseWriter, r *http.Request) {
	if h.currentUser(r) != nil {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}
	if err := r.ParseForm(); err != nil {
		h.flashError(w, r, "invalid form")
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}
	nick := strings.TrimSpace(r.FormValue("nickname"))
	challenge := strings.TrimSpace(r.FormValue("pow_challenge"))
	nonce := strings.TrimSpace(r.FormValue("pow_nonce"))

	if nick == "" || challenge == "" || nonce == "" {
		h.flashError(w, r, "All fields are required")
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}

	nick, err := validateNickname(nick)
	if err != nil {
		h.flashError(w, r, err.Error())
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}

	// Проверяем PoW
	ok, err := h.PoW.Verify(r.Context(), challenge, nonce, "register")
	if err != nil || !ok {
		h.flashError(w, r, "Proof-of-Work invalid or expired. Please try again.")
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}

	// Генерируем пару ключей
	privPEM, pubB64, err := h.Keys.GeneratePair()
	if err != nil {
		h.flashError(w, r, "Key generation failed: "+err.Error())
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}

	// Создаём юзера
	user, err := h.DB.CreateUser(r.Context(), nick, pubB64)
	if err != nil {
		if db.IsUniqueViolation(err) {
			h.flashError(w, r, "Nickname already taken. You can still log in with your .key file if it's yours.")
		} else {
			h.flashError(w, r, "DB error: "+err.Error())
		}
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}

	// Сразу логиним нового юзера
	signed, err := h.Auth.NewSession(r.Context(), user.ID)
	if err != nil {
		// Юзер создан, но сессию не подняли — пусть залогинится вручную.
		h.flashError(w, r, "Account created, but session failed. Please log in with your .key file.")
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	h.Auth.SetCookie(w, signed)

	// Рендерим страницу успеха с ключом (один раз показываем!)
	// ВАЖНО: приватный ключ НЕ сохраняем нигде в БД. Только отдаём юзеру.
	h.renderPage(w, r, "pages/register_success.html", "Welcome!", "",
		map[string]any{
			"user":         user,
			"private_key":  privPEM,
			"key_filename": "libtd_" + nick + ".key",
		})
}

// --- Login ---

// LoginPage — GET /login.
func (h *Handlers) LoginPage(w http.ResponseWriter, r *http.Request) {
	if h.currentUser(r) != nil {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}
	errMsg, _ := h.readFlash(w, r)
	h.renderPage(w, r, "pages/login.html", "Login", "",
		map[string]any{"flash_error": errMsg})
}

// LoginSubmit — POST /login.
//
// Параметры формы (multipart/form-data):
//   - nickname
//   - private_key (textarea)
//   - keyfile (file upload, опционально, заменяет textarea)
//   - pow_challenge
//   - pow_nonce
//
// Алгоритм:
//   1. Проверяем PoW (purpose = "login").
//   2. Находим юзера по нику.
//   3. Парсим приватный ключ (PEM).
//   4. Генерируем случайный nonce (32 байта).
//   5. Подписываем nonce приватным ключом (на сервере — это безопасно,
//      т.к. ключ не покидает рамки запроса) и проверяем публичным из БД.
//      Если подпись валидна — значит приватный ключ соответствует публичному
//      в БД, юзер аутентифицирован.
//   6. Ставим сессионную куку.
func (h *Handlers) LoginSubmit(w http.ResponseWriter, r *http.Request) {
	if h.currentUser(r) != nil {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}
	// Лимит 1 МБ на форму (приватный ключ — это ~500 байт PEM).
	if err := r.ParseMultipartForm(1 << 20); err != nil {
		// Возможно, форма не multipart — пробуем обычный parse.
		if err2 := r.ParseForm(); err2 != nil {
			h.flashError(w, r, "invalid form")
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}
	}

	nick := strings.TrimSpace(r.FormValue("nickname"))
	challenge := strings.TrimSpace(r.FormValue("pow_challenge"))
	nonce := strings.TrimSpace(r.FormValue("pow_nonce"))

	// Приватный ключ — из файла ИЛИ из textarea.
	privPEM := strings.TrimSpace(r.FormValue("private_key"))
	if privPEM == "" {
		if f, hdr, err := r.FormFile("keyfile"); err == nil {
			defer f.Close()
			if hdr.Size > 1<<20 {
				h.flashError(w, r, "Key file too large")
				http.Redirect(w, r, "/login", http.StatusSeeOther)
				return
			}
			buf := make([]byte, hdr.Size)
			_, _ = f.Read(buf)
			privPEM = strings.TrimSpace(string(buf))
		}
	}

	if nick == "" || challenge == "" || nonce == "" || privPEM == "" {
		h.flashError(w, r, "All fields are required (nickname, key, PoW)")
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	nick, err := validateNickname(nick)
	if err != nil {
		h.flashError(w, r, err.Error())
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// 1) PoW
	ok, err := h.PoW.Verify(r.Context(), challenge, nonce, "login")
	if err != nil || !ok {
		h.flashError(w, r, "Proof-of-Work invalid or expired. Please try again.")
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// 2) Юзер по нику
	user, err := h.DB.UserByNickname(r.Context(), nick)
	if err != nil {
		if errors.Is(err, db.ErrNotFound) {
			h.flashError(w, r, "User not found. Register first.")
		} else {
			h.flashError(w, r, "DB error: "+err.Error())
		}
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// 3) Парсим приватный ключ
	privKey, err := h.Keys.ParsePrivateKey(privPEM)
	if err != nil {
		h.flashError(w, r, "Invalid private key file: "+err.Error())
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// 4) Подписываем случайный nonce и проверяем публичным ключом из БД.
	nonceBytes := make([]byte, 32)
	if _, err := rand.Read(nonceBytes); err != nil {
		h.flashError(w, r, "Crypto failure")
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	sig, err := h.Keys.Sign(privKey, nonceBytes)
	if err != nil {
		h.flashError(w, r, "Signing failed: "+err.Error())
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	verifyOk, err := h.Keys.VerifyPub(user.PublicKey, nonceBytes, sig)
	if err != nil || !verifyOk {
		h.flashError(w, r, "Private key does not match this account's public key")
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// 5) Ставим сессию
	signed, err := h.Auth.NewSession(r.Context(), user.ID)
	if err != nil {
		h.flashError(w, r, "Session failed: "+err.Error())
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	h.Auth.SetCookie(w, signed)
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

// Logout — POST /logout.
func (h *Handlers) Logout(w http.ResponseWriter, r *http.Request) {
	_ = h.Auth.Logout(r.Context(), r)
	h.Auth.ClearCookie(w)
	http.Redirect(w, r, "/", http.StatusSeeOther)
}
