// Package handlers — HTTP-хендлеры форума.
//
// Структура Handlers держит все зависимости и работает как "толстый контроллер":
// читает запрос, дёргает DB / Storage / Auth, рендерит ответ (полная страница
// или HTMX-фрагмент).
package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/libtd/libtd/internal/auth"
	"github.com/libtd/libtd/internal/config"
	"github.com/libtd/libtd/internal/db"
	"github.com/libtd/libtd/internal/middleware"
	"github.com/libtd/libtd/internal/models"
	"github.com/libtd/libtd/internal/storage"
	"github.com/libtd/libtd/internal/templates"
)

// Handlers — агрегатор всех зависимостей хендлеров.
type Handlers struct {
	Cfg     *config.Config
	DB      *db.DB
	Storage storage.FileStorage
	Auth    *auth.Sessions
	PoW     *auth.PoW
	Keys    auth.Keys
	Tmpls   *templates.Renderer
}

// --- общие хелперы ---

// currentUser — короткий хелпер для доставания юзера из контекста.
// Ключ контекста задаётся в middleware.WithUser.
func (h *Handlers) currentUser(r *http.Request) *models.User {
	return middleware.UserFromContext(r.Context())
}

// renderPage — короткий хелпер для рендера полной страницы с подкладыванием
// общих данных (юзер, активный раздел, подписки).
func (h *Handlers) renderPage(w http.ResponseWriter, r *http.Request, name string, title, active string, extra map[string]any) {
	data := templates.PageData{
		Title:       title,
		Active:      active,
		CurrentUser: h.currentUser(r),
		Extra:       extra,
	}
	if errVal, ok := extra["flash_error"]; ok {
		_ = errVal
	}
	if boards, err := h.DB.ListBoards(r.Context()); err == nil {
		data.Boards = boards
	}
	if u := h.currentUser(r); u != nil {
		if subs, err := h.DB.ListSubscribedBoards(r.Context(), u.ID); err == nil {
			data.SubscribedBoards = subs
		}
	}
	if errStr, okStr := extra["flash_error"].(string); okStr {
		_ = errStr
	}
	if succStr, okStr := extra["flash_success"].(string); okStr {
		_ = succStr
	}
	h.Tmpls.RenderPageHTTP(w, name, data)
}

// parseInt64 парсит URL-параметр и возвращает ошибку при некорректном значении.
func parseInt64(s string) (int64, error) {
	return strconv.ParseInt(s, 10, 64)
}

// safeError возвращает пользователю человекочитаемое сообщение.
// В проде скрываем технические детали, в dev — возвращаем как есть.
func (h *Handlers) safeError(w http.ResponseWriter, msg string, code int) {
	if h.Cfg.Env == "dev" {
		http.Error(w, msg, code)
		return
	}
	http.Error(w, http.StatusText(code), code)
}

// flashError — кладёт сообщение об ошибке в cookie и редиректит.
// (простейшая реализация flash-сообщений без дополнительной инфраструктуры)
func (h *Handlers) flashError(w http.ResponseWriter, r *http.Request, msg string) {
	http.SetCookie(w, &http.Cookie{
		Name:     "flash_error",
		Value:    msg,
		Path:     "/",
		MaxAge:   30,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
}

// flashSuccess — аналогично, но для позитивных сообщений.
func (h *Handlers) flashSuccess(w http.ResponseWriter, r *http.Request, msg string) {
	http.SetCookie(w, &http.Cookie{
		Name:     "flash_success",
		Value:    msg,
		Path:     "/",
		MaxAge:   30,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
}

// readFlash возвращает и тут же очищает flash-сообщения из кук.
func (h *Handlers) readFlash(w http.ResponseWriter, r *http.Request) (errMsg string, succMsg string) {
	if c, err := r.Cookie("flash_error"); err == nil {
		errMsg = c.Value
		http.SetCookie(w, &http.Cookie{Name: "flash_error", Path: "/", MaxAge: -1})
	}
	if c, err := r.Cookie("flash_success"); err == nil {
		succMsg = c.Value
		http.SetCookie(w, &http.Cookie{Name: "flash_success", Path: "/", MaxAge: -1})
	}
	return
}

// writeJSON — пишет JSON-ответ.
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

// --- Home / NotFound ---

// Home — редирект на доску по умолчанию.
func (h *Handlers) Home(w http.ResponseWriter, r *http.Request) {
	http.Redirect(w, r, "/"+h.Cfg.DefaultBoardSlug, http.StatusSeeOther)
}

// NotFound — кастомная 404.
func (h *Handlers) NotFound(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusNotFound)
	h.renderPage(w, r, "pages/404.html", "Not Found", "", map[string]any{})
}

// PoWChallenge — GET /pow/{purpose}. Возвращает JSON {challenge, algorithm}.
// purpose: "register" | "login".
func (h *Handlers) PowChallenge(w http.ResponseWriter, r *http.Request) {
	purpose := chi.URLParam(r, "purpose")
	if purpose != "register" && purpose != "login" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid purpose"})
		return
	}
	ch, err := h.PoW.Generate(r.Context(), purpose)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "pow generate failed"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"challenge": ch,
		"algorithm": "sha256",
		"rule":      "find nonce N (integer) such that sha256(challenge + ':' + str(N)) contains challenge",
		"separator": ":",
		"maxIter":   10_000_000,
	})
}

// requireUser возвращает текущего юзера или пишет 401. Используется в HTMX-только
// хендлерах, которые не покрыты middleware.RequireAuth (на всякий случай —
// у нас все защищённые маршруты уже обёрнуты middleware).
func (h *Handlers) requireUser(w http.ResponseWriter, r *http.Request) *models.User {
	u := h.currentUser(r)
	if u == nil {
		w.Header().Set("HX-Redirect", "/login")
		w.WriteHeader(http.StatusUnauthorized)
		return nil
	}
	return u
}

// trim и validate nickname: 3–32 символа, [a-zA-Z0-9_-]
func validateNickname(nick string) (string, error) {
	nick = strings.TrimSpace(nick)
	if len(nick) < 3 || len(nick) > 32 {
		return "", errors.New("nickname must be 3..32 chars")
	}
	for _, c := range nick {
		ok := (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') || c == '_' || c == '-'
		if !ok {
			return "", fmt.Errorf("nickname contains invalid char %q", c)
		}
	}
	return nick, nil
}
