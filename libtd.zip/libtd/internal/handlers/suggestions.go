package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/libtd/libtd/internal/db"
)

// SuggestionsPage — GET /suggestions.
func (h *Handlers) SuggestionsPage(w http.ResponseWriter, r *http.Request) {
	user := h.currentUser(r)
	var userID int64
	if user != nil {
		userID = user.ID
	}
	suggestions, err := h.DB.ListSuggestions(r.Context(), userID)
	if err != nil && !errors.Is(err, db.ErrNotFound) {
		h.safeError(w, "suggestions fetch: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.renderPage(w, r, "pages/suggestions.html", "Board Suggestions", "suggestions", map[string]any{
		"suggestions": suggestions,
	})
}

// SuggestionCreate — POST /suggestions.
func (h *Handlers) SuggestionCreate(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if err := r.ParseForm(); err != nil {
		h.safeError(w, "invalid form", http.StatusBadRequest)
		return
	}
	name := strings.TrimSpace(r.FormValue("name"))
	if len(name) < 2 || len(name) > 32 {
		h.safeError(w, "name must be 2..32 chars", http.StatusBadRequest)
		return
	}

	s, err := h.DB.CreateSuggestion(r.Context(), u.ID, name)
	if err != nil {
		h.safeError(w, "create suggestion: "+err.Error(), http.StatusInternalServerError)
		return
	}
	s.AuthorNick = u.Nickname
	s.Voted = false

	// HTMX: фрагмент новой карточки
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	_ = h.Tmpls.RenderFragment(w, "fragments/suggestion_card.html", map[string]any{
		"suggestion":  s,
		"currentUser": u,
	})
}

// SuggestionVote — POST /suggestions/{id}/vote.
func (h *Handlers) SuggestionVote(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	id, err := parseInt64(chi.URLParam(r, "id"))
	if err != nil {
		h.safeError(w, "bad id", http.StatusBadRequest)
		return
	}
	if err := h.DB.VoteSuggestion(r.Context(), u.ID, id); err != nil {
		h.safeError(w, "vote: "+err.Error(), http.StatusInternalServerError)
		return
	}
	// Перечитываем обновлённую запись
	s, err := h.DB.SuggestionByID(r.Context(), id)
	if err != nil {
		h.safeError(w, "fetch: "+err.Error(), http.StatusInternalServerError)
		return
	}
	s.Voted = true
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_ = h.Tmpls.RenderFragment(w, "fragments/suggestion_card.html", map[string]any{
		"suggestion":  s,
		"currentUser": u,
	})
}
