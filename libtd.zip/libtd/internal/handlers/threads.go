package handlers

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"path"
	"strconv"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/libtd/libtd/internal/db"
	"github.com/libtd/libtd/internal/models"
)

// --- BoardView ---

// BoardView — GET /{boardSlug}.
// Показывает последние треды доски + форму нового треда (если юзер залогинен).
func (h *Handlers) BoardView(w http.ResponseWriter, r *http.Request) {
	slug := chi.URLParam(r, "boardSlug")
	if slug == "" {
		slug = h.Cfg.DefaultBoardSlug
	}
	board, err := h.DB.BoardBySlug(r.Context(), slug)
	if err != nil {
		if errors.Is(err, db.ErrNotFound) {
			h.NotFound(w, r)
			return
		}
		h.safeError(w, "board fetch: "+err.Error(), http.StatusInternalServerError)
		return
	}

	page := 1
	if p := r.URL.Query().Get("page"); p != "" {
		if v, err := strconv.Atoi(p); err == nil && v > 0 {
			page = v
		}
	}
	const perPage = 20
	offset := (page - 1) * perPage

	threads, err := h.DB.ListThreadsByBoard(r.Context(), board.ID, perPage, offset)
	if err != nil && !errors.Is(err, db.ErrNotFound) {
		h.safeError(w, "threads fetch: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Подгружаем вложения для каждого треда (одним запросом нет — оставлено на будущее).
	for i := range threads {
		atts, err := h.DB.AttachmentsFor(r.Context(), "thread", threads[i].ID)
		if err == nil {
			threads[i].Attachments = atts
		}
	}

	isMod := false
	if u := h.currentUser(r); u != nil {
		isMod, _ = h.DB.IsModerator(r.Context(), u.ID, board.ID)
	}

	h.renderPage(w, r, "pages/board.html", board.Name, board.Slug, map[string]any{
		"board":        board,
		"threads":      threads,
		"page":         page,
		"perPage":      perPage,
		"isModerator":  isMod || (h.currentUser(r) != nil && h.currentUser(r).IsSuperAdmin),
		"maxFileSize":  h.maxFileSize(r),
	})
}

// maxFileSize возвращает актуальный лимит: из БД (settings.max_file_size) или из конфига.
func (h *Handlers) maxFileSize(r *http.Request) int64 {
	if v, err := h.DB.GetSetting(r.Context(), "max_file_size"); err == nil && v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil && n > 0 {
			return n
		}
	}
	return h.Cfg.MaxFileSize
}

// --- NewThread ---

// NewThreadPage — GET /{boardSlug}/new.
func (h *Handlers) NewThreadPage(w http.ResponseWriter, r *http.Request) {
	slug := chi.URLParam(r, "boardSlug")
	board, err := h.DB.BoardBySlug(r.Context(), slug)
	if err != nil {
		h.NotFound(w, r)
		return
	}
	h.renderPage(w, r, "pages/new_thread.html", "New thread", board.Slug, map[string]any{
		"board":       board,
		"maxFileSize": h.maxFileSize(r),
	})
}

// NewThreadSubmit — POST /{boardSlug}/new.
// multipart/form-data (hx-encoding).
func (h *Handlers) NewThreadSubmit(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	slug := chi.URLParam(r, "boardSlug")
	board, err := h.DB.BoardBySlug(r.Context(), slug)
	if err != nil {
		h.NotFound(w, r)
		return
	}

	maxSize := h.maxFileSize(r)
	if err := r.ParseMultipartForm(maxSize); err != nil {
		h.safeError(w, "form parse: "+err.Error(), http.StatusBadRequest)
		return
	}
	title := strings.TrimSpace(r.FormValue("title"))
	content := strings.TrimSpace(r.FormValue("content"))
	if title == "" {
		h.safeError(w, "title required", http.StatusBadRequest)
		return
	}
	if len(title) > 200 {
		h.safeError(w, "title too long (max 200 chars)", http.StatusBadRequest)
		return
	}

	thread, err := h.DB.CreateThread(r.Context(), board.ID, u.ID, title, content)
	if err != nil {
		h.safeError(w, "create thread: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Сохраняем вложения
	if err := h.saveAttachments(r, "thread", thread.ID, maxSize); err != nil {
		// не блокируем создание треда, просто логируем
		fmt.Println("WARN: attachments:", err)
	}

	// HTMX-ответ: редирект на тред
	w.Header().Set("HX-Redirect", "/"+board.Slug+"/"+strconv.FormatInt(thread.ID, 10))
	w.WriteHeader(http.StatusCreated)
}

// saveAttachments проходит по всем файлам в multipart-форме (поле "attachments")
// и сохраняет их через FileStorage + делает записи в attachments.
func (h *Handlers) saveAttachments(r *http.Request, relType string, relID int64, maxSize int64) error {
	form := r.MultipartForm
	if form == nil || form.File == nil {
		return nil
	}
	files := form.File["attachments"]
	if len(files) == 0 {
		return nil
	}
	for _, fh := range files {
		if fh.Size > maxSize {
			return fmt.Errorf("file %s too large: %d > %d", fh.Filename, fh.Size, maxSize)
		}
		f, err := fh.Open()
		if err != nil {
			return err
		}
		path, size, err := h.Storage.Save(r.Context(), f, fh.Filename, fh.Header.Get("Content-Type"))
		_ = f.Close()
		if err != nil {
			return err
		}
		if err := h.DB.AddAttachment(r.Context(), relType, relID, path, fh.Filename, size, fh.Header.Get("Content-Type")); err != nil {
			// откат: удаляем файл
			_ = h.Storage.Delete(r.Context(), path)
			return err
		}
	}
	return nil
}

// --- ThreadView ---

// ThreadView — GET /{boardSlug}/{threadID}.
func (h *Handlers) ThreadView(w http.ResponseWriter, r *http.Request) {
	slug := chi.URLParam(r, "boardSlug")
	threadIDStr := chi.URLParam(r, "threadID")
	threadID, err := parseInt64(threadIDStr)
	if err != nil {
		h.NotFound(w, r)
		return
	}

	board, err := h.DB.BoardBySlug(r.Context(), slug)
	if err != nil {
		h.NotFound(w, r)
		return
	}
	thread, err := h.DB.ThreadByID(r.Context(), threadID)
	if err != nil {
		h.NotFound(w, r)
		return
	}
	if thread.BoardID != board.ID {
		h.NotFound(w, r)
		return
	}

	replies, err := h.DB.ListRepliesByThread(r.Context(), threadID)
	if err != nil && !errors.Is(err, db.ErrNotFound) {
		h.safeError(w, "replies fetch: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// Подгружаем вложения для треда и ответов, строим дерево ответов.
	thread.Attachments, _ = h.DB.AttachmentsFor(r.Context(), "thread", thread.ID)
	replyMap := make(map[int64]*models.Reply, len(replies))
	for i := range replies {
		replies[i].Attachments, _ = h.DB.AttachmentsFor(r.Context(), "reply", replies[i].ID)
		replyMap[replies[i].ID] = &replies[i]
	}

	// Цитата родителя (для блока "-> [ник #id]: ...")
	for i := range replies {
		if replies[i].ReplyToID != nil {
			if parent, ok := replyMap[*replies[i].ReplyToID]; ok {
				replies[i].ReplyTo = parent
			}
		}
	}

	// Дерево: Children для каждого ответа.
	var roots []models.Reply
	for i := range replies {
		rp := &replies[i]
		if rp.ReplyToID == nil {
			roots = append(roots, *rp)
		} else if parent, ok := replyMap[*rp.ReplyToID]; ok {
			parent.Children = append(parent.Children, *rp)
		} else {
			// родитель удалён — показываем как корень
			roots = append(roots, *rp)
		}
	}

	isMod := false
	if u := h.currentUser(r); u != nil {
		isMod, _ = h.DB.IsModerator(r.Context(), u.ID, board.ID)
		isMod = isMod || u.IsSuperAdmin
	}

	h.renderPage(w, r, "pages/thread.html", thread.Title, board.Slug, map[string]any{
		"board":        board,
		"thread":       thread,
		"replies":      roots, // корни дерева
		"isModerator":  isMod,
		"maxFileSize":  h.maxFileSize(r),
		"currentUser":  h.currentUser(r),
	})
}

// --- Reply ---

// ReplySubmit — POST /{boardSlug}/{threadID}/reply (или /reply/{replyID}).
// Принимает plain form (текст) + multipart files (опционально).
func (h *Handlers) ReplySubmit(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	threadID, err := parseInt64(chi.URLParam(r, "threadID"))
	if err != nil {
		h.NotFound(w, r)
		return
	}
	thread, err := h.DB.ThreadByID(r.Context(), threadID)
	if err != nil {
		h.NotFound(w, r)
		return
	}

	maxSize := h.maxFileSize(r)
	// Допускаем и multipart (с файлами), и обычную форму (без файлов).
	var hasFiles bool
	if err := r.ParseMultipartForm(maxSize); err == nil && r.MultipartForm != nil && len(r.MultipartForm.File["attachments"]) > 0 {
		hasFiles = true
	} else if err := r.ParseForm(); err != nil {
		h.safeError(w, "form parse error", http.StatusBadRequest)
		return
	}

	content := strings.TrimSpace(r.FormValue("content"))
	if content == "" {
		h.safeError(w, "content required", http.StatusBadRequest)
		return
	}
	if len(content) > 10_000 {
		h.safeError(w, "content too long (max 10000 chars)", http.StatusBadRequest)
		return
	}

	var replyToID *int64
	if rid := chi.URLParam(r, "replyID"); rid != "" {
		if v, err := parseInt64(rid); err == nil {
			// проверяем, что ответ существует и в том же треде
			parent, err := h.DB.ReplyByID(r.Context(), v)
			if err == nil && parent.ThreadID == thread.ID {
				replyToID = &v
			}
		}
	}

	reply, err := h.DB.CreateReply(r.Context(), thread.ID, u.ID, content, replyToID)
	if err != nil {
		h.safeError(w, "create reply: "+err.Error(), http.StatusInternalServerError)
		return
	}

	if hasFiles {
		if err := h.saveAttachments(r, "reply", reply.ID, maxSize); err != nil {
			fmt.Println("WARN: attachments in reply:", err)
		}
	}

	// Перечитываем ответ с аттачами + родителем
	replyFull, _ := h.DB.ReplyByID(r.Context(), reply.ID)
	if replyFull != nil {
		reply = replyFull
	}
	reply.Attachments, _ = h.DB.AttachmentsFor(r.Context(), "reply", reply.ID)
	if reply.ReplyToID != nil {
		parent, _ := h.DB.ReplyByID(r.Context(), *reply.ReplyToID)
		reply.ReplyTo = parent
	}
	reply.AuthorNick = u.Nickname

	// HTMX: возвращаем фрагмент нового ответа + out-of-band swap для формы
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	_ = h.Tmpls.RenderFragment(w, "fragments/reply_tree.html", map[string]any{
		"reply":       reply,
		"board":       map[string]any{"slug": chi.URLParam(r, "boardSlug")},
		"thread":      thread,
		"currentUser": h.currentUser(r),
	})
}

// --- DeleteThread ---

// DeleteThread — DELETE /{boardSlug}/thread/{threadID}.
// Доступ: автор треда, модератор доски, супер-админ.
func (h *Handlers) DeleteThread(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	threadID, err := parseInt64(chi.URLParam(r, "threadID"))
	if err != nil {
		h.NotFound(w, r)
		return
	}
	thread, err := h.DB.ThreadByID(r.Context(), threadID)
	if err != nil {
		h.NotFound(w, r)
		return
	}

	board, _ := h.DB.BoardBySlug(r.Context(), chi.URLParam(r, "boardSlug"))
	canDelete := u.IsSuperAdmin || thread.AuthorID == u.ID
	if !canDelete && board != nil {
		canDelete, _ = h.DB.IsModerator(r.Context(), u.ID, board.ID)
	}
	if !canDelete {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	// Удаляем вложения из хранилища
	atts, _ := h.DB.AttachmentsFor(r.Context(), "thread", threadID)
	for _, a := range atts {
		_ = h.Storage.Delete(r.Context(), a.FilePath)
	}
	_ = h.DB.DeleteAttachmentsFor(r.Context(), "thread", threadID)

	if err := h.DB.DeleteThread(r.Context(), threadID); err != nil {
		h.safeError(w, "delete thread: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("HX-Redirect", "/"+chi.URLParam(r, "boardSlug"))
	w.WriteHeader(http.StatusOK)
}

// --- Subscribe / Unsubscribe ---

// Subscribe — POST /subscribe/{boardID}.
func (h *Handlers) Subscribe(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	boardID, err := parseInt64(chi.URLParam(r, "boardID"))
	if err != nil {
		h.safeError(w, "bad board id", http.StatusBadRequest)
		return
	}
	if err := h.DB.Subscribe(r.Context(), u.ID, boardID); err != nil {
		h.safeError(w, "subscribe: "+err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// Unsubscribe — POST /unsubscribe/{boardID}.
func (h *Handlers) Unsubscribe(w http.ResponseWriter, r *http.Request) {
	u := h.currentUser(r)
	if u == nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	boardID, err := parseInt64(chi.URLParam(r, "boardID"))
	if err != nil {
		h.safeError(w, "bad board id", http.StatusBadRequest)
		return
	}
	if err := h.DB.Unsubscribe(r.Context(), u.ID, boardID); err != nil {
		h.safeError(w, "unsubscribe: "+err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// --- helpers ---

// attachmentURL — формирует публичный URL файла (для шаблона).
func (h *Handlers) attachmentURL(p string) string {
	return h.Storage.URL(p)
}

// stub для подавления unused импортов
var _ = io.EOF
var _ = path.Base
