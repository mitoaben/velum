// Package middleware — общие HTTP-посредники: аутентификация, роли, csrf, log.
package middleware

import (
	"context"
	"net/http"

	"github.com/libtd/libtd/internal/auth"
	"github.com/libtd/libtd/internal/models"
)

type ctxKey string

const (
	userCtxKey ctxKey = "user"
)

// UserFromContext достаёт юзера, добавленного middleware Auth.
// Если юзера нет — возвращает nil.
func UserFromContext(ctx context.Context) *models.User {
	v, _ := ctx.Value(userCtxKey).(*models.User)
	return v
}

// WithUser кладёт юзера в контекст. Используется тестами и Auth.
func WithUser(ctx context.Context, u *models.User) context.Context {
	return context.WithValue(ctx, userCtxKey, u)
}

// Auth пробует разрешить сессию и кладёт юзера в контекст.
// НЕ блокирует запрос — анонимы тоже ходят на сайт. Для блокировки есть RequireAuth.
func Auth(sessions *auth.Sessions) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			u, err := sessions.ResolveFromRequest(r.Context(), r)
			if err == nil && u != nil {
				r = r.WithContext(WithUser(r.Context(), u))
			}
			next.ServeHTTP(w, r)
		})
	}
}

// RequireAuth пускает только аутентифицированных юзеров. Иначе — 401/redirect.
func RequireAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if UserFromContext(r.Context()) == nil {
			// Для HTMX-запроса — простой 401, для обычного — редирект на /login.
			if r.Header.Get("HX-Request") == "true" {
				w.Header().Set("HX-Redirect", "/login")
				w.WriteHeader(http.StatusUnauthorized)
				return
			}
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}
		next.ServeHTTP(w, r)
	})
}

// RequireSuperAdmin пускает только is_super_admin.
func RequireSuperAdmin(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		u := UserFromContext(r.Context())
		if u == nil || !u.IsSuperAdmin {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		next.ServeHTTP(w, r)
	})
}
