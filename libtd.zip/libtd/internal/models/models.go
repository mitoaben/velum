// Package models содержит доменные типы форума.
// Структуры намеренно "плоские" — они отображают строки таблиц 1:1,
// бизнес-логика живёт в handlers/services, а не здесь.
package models

import "time"

// User — пользователь форума.
type User struct {
	ID           int64
	Nickname     string
	PublicKey    string
	IsSuperAdmin bool
	IsModerator  bool
	CreatedAt    time.Time
}

// DisplayName возвращает строку вида "Anonymous #45" для рендера в шаблонах.
func (u User) DisplayName() string { return u.Nickname + " #" + itoa(u.ID) }

// Board — доска форума.
type Board struct {
	ID          int64
	Slug        string
	Name        string
	Description string
	CreatorID   int64
	CreatedAt   time.Time
}

// Thread — тред (топик) внутри доски.
type Thread struct {
	ID           int64
	BoardID      int64
	AuthorID     int64
	AuthorNick   string // для удобного рендера
	Title        string
	Content      string
	CreatedAt    time.Time
	ReplyCount   int
	Attachments  []Attachment
}

// Reply — ответ в треде. Поддерживает древовидность через ReplyToID.
type Reply struct {
	ID           int64
	ThreadID     int64
	AuthorID     int64
	AuthorNick   string
	Content      string
	ReplyToID    *int64
	ReplyTo      *Reply // родительский ответ для отображения цитаты (filled by service)
	CreatedAt    time.Time
	Attachments  []Attachment
	Children     []Reply // дочерние ответы, выстроенные в дерево
}

// Attachment — файл, приложенный к треду или ответу.
type Attachment struct {
	ID        int64
	RelID     int64
	RelType   string // 'thread' | 'reply'
	FilePath  string // путь/ключ в FileStorage
	FileName  string
	FileSize  int64
	MimeType  string
	CreatedAt time.Time
}

// BoardSuggestion — предложение создать новую доску.
type BoardSuggestion struct {
	ID        int64
	AuthorID  int64
	AuthorNick string
	Name      string
	Votes     int
	Status    string // 'open' | 'approved' | 'rejected'
	CreatedAt time.Time
	Voted     bool // голосовал ли текущий юзер (filled by service)
}

// Session — сессия пользователя.
type Session struct {
	Token     string
	UserID    int64
	CreatedAt time.Time
	ExpiresAt time.Time
}

// --- tiny helpers (без strconv, чтобы избежать пакета импортов в шаблонах) ---

func itoa(n int64) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var buf [20]byte
	i := len(buf)
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
