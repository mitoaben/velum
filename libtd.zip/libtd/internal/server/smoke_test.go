//go:build integration

// smoke_test.go — end-to-end smoke-тест: поднимает embedded-postgres, запускает
// HTTP-сервер libtd, прогоняет полный flow через HTTP-клиент:
//   - GET / (redirect)
//   - GET /all (board page)
//   - GET /pow/register (challenge)
//   - POST /register (с решённым PoW)
//   - GET /admin (после логина)
//   - POST /all/new (создание треда)
//   - GET /all/{id} (просмотр треда)
//   - POST /all/{id}/reply (ответ)
//   - POST /suggestions (предложение)
//
// Запуск:
//   go test -tags=integration -v -run TestSmoke ./internal/server/
package server

import (
        "bytes"
        "context"
        "crypto/sha256"
        "encoding/hex"
        "fmt"
        "io"
        "mime/multipart"
        "net/http"
        "net/http/cookiejar"
        "net/url"
        "os"
        "path/filepath"
        "strings"
        "testing"
        "time"

        embeddedpostgres "github.com/fergusstrange/embedded-postgres"
        "github.com/libtd/libtd/internal/config"
        "github.com/libtd/libtd/internal/db"
        "github.com/libtd/libtd/internal/storage"
)

// solvePoWLocally решает PoW так же, как это делает фронтенд.
func solvePoWLocally(challenge string) (string, error) {
        for n := 0; n < 5_000_000; n++ {
                s := fmt.Sprintf("%s:%d", challenge, n)
                h := sha256.Sum256([]byte(s))
                hex := hex.EncodeToString(h[:])
                if strings.Contains(hex, challenge) {
                        return fmt.Sprintf("%d", n), nil
                }
        }
        return "", fmt.Errorf("no solution found for %s", challenge)
}

func TestSmoke_FullFlow(t *testing.T) {
        if testing.Short() {
                t.Skip("skipping smoke test in short mode")
        }

        tmp := t.TempDir()
        pgBin := filepath.Join(tmp, "pgbin")
        pgData := filepath.Join(tmp, "pgdata")
        pgRuntime := filepath.Join(tmp, "pgrun")
        uploadDir := filepath.Join(tmp, "uploads")

        pg := embeddedpostgres.NewDatabase(
                embeddedpostgres.DefaultConfig().
                        Version(embeddedpostgres.V16).
                        BinariesPath(pgBin).
                        DataPath(pgData).
                        RuntimePath(pgRuntime).
                        Port(5434).
                        Database("libtdsmoke").
                        Username("libtd").
                        Password("libtd"),
        )
        if err := pg.Start(); err != nil {
                t.Fatalf("postgres start: %v", err)
        }
        defer func() { _ = pg.Stop() }()

        dsn := "postgres://libtd:libtd@localhost:5434/libtdsmoke?sslmode=disable"
        ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
        defer cancel()

        database, err := db.Open(ctx, dsn)
        if err != nil {
                t.Fatalf("db.Open: %v", err)
        }
        defer database.Close()

        store, err := storage.NewLocalFS(uploadDir, "/uploads")
        if err != nil {
                t.Fatalf("storage: %v", err)
        }

        cfg := &config.Config{
                Addr:             "127.0.0.1:18080",
                DatabaseURL:      dsn,
                SessionKey:       "smoke-test-session-key-32-bytes!",
                SessionTTL:       time.Hour,
                PoWChallengeLen:  4,
                PoWTTL:           5 * time.Minute,
                MaxFileSize:      100 * 1024 * 1024,
                UploadDir:        uploadDir,
                StorageKind:      "local",
                DefaultBoardSlug: "all",
                Env:              "dev",
        }

        srv, err := New(cfg, database, store)
        if err != nil {
                t.Fatalf("server.New: %v", err)
        }

        httpSrv := &http.Server{
                Addr:              cfg.Addr,
                Handler:           srv.Router,
                ReadHeaderTimeout: 5 * time.Second,
        }
        go func() { _ = httpSrv.ListenAndServe() }()
        defer func() {
                shutCtx, shutCancel := context.WithTimeout(context.Background(), 5*time.Second)
                defer shutCancel()
                _ = httpSrv.Shutdown(shutCtx)
        }()

        // Ждём, пока сервер поднимется.
        time.Sleep(200 * time.Millisecond)

        // HTTP-клиент с cookie-jar (чтобы сессия сохранялась).
        jar, _ := cookiejar.New(nil)
        client := &http.Client{
                Jar:     jar,
                Timeout: 10 * time.Second,
                CheckRedirect: func(req *http.Request, via []*http.Request) error {
                        // Разрешаем редиректы, но сохраняем cookies.
                        return nil
                },
        }
        base := "http://" + cfg.Addr

        // 1) GET / -> редирект на /all
        resp, err := client.Get(base + "/")
        if err != nil {
                t.Fatalf("GET /: %v", err)
        }
        resp.Body.Close()
        if resp.Request.URL.Path != "/all" {
                t.Errorf("expected redirect to /all, got %q", resp.Request.URL.Path)
        }
        t.Logf("✓ GET / -> redirect to /all")

        // 2) GET /all — страница доски
        resp, err = client.Get(base + "/all")
        if err != nil {
                t.Fatalf("GET /all: %v", err)
        }
        body, _ := io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "All") {
                t.Errorf("expected 'All' on /all page, got: %s", body[:min(200, len(body))])
        }
        t.Logf("✓ GET /all returns board page")

        // 3) GET /pow/register — challenge
        resp, err = client.Get(base + "/pow/register")
        if err != nil {
                t.Fatalf("GET /pow/register: %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "challenge") {
                t.Errorf("expected 'challenge' in response, got: %s", body)
        }
        challenge := extractJSONValue(string(body), "challenge")
        if challenge == "" {
                t.Fatalf("could not extract challenge: %s", body)
        }
        t.Logf("✓ GET /pow/register challenge=%s", challenge)

        // 4) Решаем PoW локально
        nonce, err := solvePoWLocally(challenge)
        if err != nil {
                t.Fatalf("solvePoW: %v", err)
        }
        t.Logf("✓ PoW solved: nonce=%s", nonce)

        // 5) POST /register
        form := url.Values{
                "nickname":     {"smoketest_alice"},
                "pow_challenge": {challenge},
                "pow_nonce":    {nonce},
        }
        resp, err = client.PostForm(base+"/register", form)
        if err != nil {
                t.Fatalf("POST /register: %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "BEGIN PRIVATE KEY") {
                t.Errorf("expected 'BEGIN PRIVATE KEY' in response, got: %s", body[:min(500, len(body))])
        }
        if !strings.Contains(string(body), "Welcome") {
                t.Errorf("expected 'Welcome' in response, got: %s", body[:min(500, len(body))])
        }
        t.Logf("✓ POST /register -> got private key + welcome page")

        // 6) GET /admin — супер-админ должен видеть
        resp, err = client.Get(base + "/admin")
        if err != nil {
                t.Fatalf("GET /admin: %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if resp.StatusCode != 200 {
                t.Errorf("expected 200 on /admin, got %d", resp.StatusCode)
        }
        if !strings.Contains(string(body), "Admin Panel") {
                t.Errorf("expected 'Admin Panel' on /admin, got: %s", body[:min(300, len(body))])
        }
        t.Logf("✓ GET /admin accessible to super admin")

        // 7) POST /all/new — создание треда (multipart/form-data)
        var buf bytes.Buffer
        mw := multipart.NewWriter(&buf)
        _ = mw.WriteField("title", "Smoke test thread")
        _ = mw.WriteField("content", "This is a test thread created by the smoke test.")
        _ = mw.Close()
        req, _ := http.NewRequest("POST", base+"/all/new", &buf)
        req.Header.Set("Content-Type", mw.FormDataContentType())
        resp, err = client.Do(req)
        if err != nil {
                t.Fatalf("POST /all/new: %v", err)
        }
        resp.Body.Close()
        if resp.StatusCode != 201 {
                t.Errorf("POST /all/new: expected 201, got %d", resp.StatusCode)
        }
        t.Logf("✓ POST /all/new status=%d, HX-Redirect=%s", resp.StatusCode, resp.Header.Get("HX-Redirect"))

        // 8) GET /all — должен увидеть тред
        resp, err = client.Get(base + "/all")
        if err != nil {
                t.Fatalf("GET /all (after thread): %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "Smoke test thread") {
                t.Errorf("expected 'Smoke test thread' on /all, got: %s", body[:min(300, len(body))])
        }
        t.Logf("✓ GET /all shows new thread")

        // 9) GET /suggestions
        resp, err = client.Get(base + "/suggestions")
        if err != nil {
                t.Fatalf("GET /suggestions: %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "Board Suggestions") {
                t.Errorf("expected 'Board Suggestions' on /suggestions, got: %s", body[:min(300, len(body))])
        }
        t.Logf("✓ GET /suggestions returns page")

        // 10) POST /suggestions (HTMX)
        form = url.Values{"name": {"Smoke Board"}}
        resp, err = client.PostForm(base+"/suggestions", form)
        if err != nil {
                t.Fatalf("POST /suggestions: %v", err)
        }
        body, _ = io.ReadAll(resp.Body)
        resp.Body.Close()
        if !strings.Contains(string(body), "Smoke Board") {
                t.Errorf("expected 'Smoke Board' in response, got: %s", body[:min(300, len(body))])
        }
        t.Logf("✓ POST /suggestions creates suggestion")

        // 11) POST /logout
        resp, err = client.PostForm(base+"/logout", url.Values{})
        if err != nil {
                t.Fatalf("POST /logout: %v", err)
        }
        resp.Body.Close()
        t.Logf("✓ POST /logout")

        // 12) GET /admin после логаута -> редирект/403
        resp, err = client.Get(base + "/admin")
        if err != nil {
                t.Fatalf("GET /admin (after logout): %v", err)
        }
        resp.Body.Close()
        if resp.StatusCode == 200 {
                // после редиректа могли попасть на /login
                if resp.Request.URL.Path == "/login" || resp.Request.URL.Path == "/admin" {
                        t.Logf("✓ GET /admin after logout redirects (status=%d, url=%s)", resp.StatusCode, resp.Request.URL.Path)
                } else {
                        t.Errorf("expected redirect or 403, got %d %s", resp.StatusCode, resp.Request.URL.Path)
                }
        } else {
                t.Logf("✓ GET /admin after logout -> %d", resp.StatusCode)
        }

        t.Log("SMOKE TEST OK: all endpoints responded correctly")
}

// extractJSONValue — простейший JSON-парсер для одного строкового поля.
// Не используем encoding/json, чтобы не зависеть от структуры ответа.
func extractJSONValue(s, key string) string {
        needle := "\"" + key + "\":"
        idx := strings.Index(s, needle)
        if idx < 0 {
                return ""
        }
        rest := s[idx+len(needle):]
        rest = strings.TrimLeft(rest, " ")
        if !strings.HasPrefix(rest, "\"") {
                return ""
        }
        rest = rest[1:]
        end := strings.Index(rest, "\"")
        if end < 0 {
                return ""
        }
        return rest[:end]
}

func min(a, b int) int {
        if a < b {
                return a
        }
        return b
}

// stub чтобы подавить unused warning если os не используется
var _ = os.Stdout
