// Package server — статика (CSS/JS) встроена в бинарник через embed.FS,
// чтобы сервер работал из любой рабочей директории, а не только из корня проекта.
package server

import (
        "embed"
        "io/fs"
        "net/http"
)

//go:embed web_static/css/* web_static/js/*
var staticFS embed.FS

// staticFilesystem возвращает http.FileSystem, читающий из встроенной web_static/.
// Файлы доступны по путям /css/... и /js/... (без префикса web_static/).
func staticFilesystem() http.FileSystem {
        sub, err := fs.Sub(staticFS, "web_static")
        if err != nil {
                // Не должно случиться — файлов нет только если embed-директива не нашла файлы,
                // но тогда бы не скомпилировалось. Паним на старте безопаснее, чем тишина в рантайме.
                panic(err)
        }
        return http.FS(sub)
}
