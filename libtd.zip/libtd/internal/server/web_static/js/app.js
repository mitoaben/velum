// app.js — клиентский скрипт libtd.
// Содержит:
//   - PoW-солвер (SHA-256, pure-JS реализация, работает в любом контексте)
//   - Хелперы для форм (drag-n-drop, file list)
//   - HTMX-хелперы (reply-to с цитатой, reset формы)
//
// ВАЖНО: НЕ используем crypto.subtle (Web Crypto API), потому что он доступен
// только в "secure context" (HTTPS или http://localhost). При доступе по IP
// (http://192.168.x.x:8080) crypto.subtle === undefined и фронт падает.
// Pure-JS SHA-256 работает везде.

// ----------------------------------------------------------------------------
// Pure-JS SHA-256 (без зависимостей, синхронная).
// Возвращает hex-строку. Производительность: ~150-300K хэшей/сек на десктопе,
// что для 4-char challenge даёт 0.5–2 секунды решения.
// ----------------------------------------------------------------------------

const SHA256_K = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]);

function rotr(x, n) { return ((x >>> n) | (x << (32 - n))) >>> 0; }

function sha256Hex(msg) {
  // Препроцессинг: padded message
  const bytes = (typeof msg === 'string')
    ? new TextEncoder().encode(msg)
    : msg;
  const len = bytes.length;
  const bitLen = len * 8;

  // Дополняем до кратного 64 байтам: +1 бит (0x80), +нули, +8 байт длина.
  const paddedLen = ((len + 9 + 63) >>> 6) << 6;
  const padded = new Uint8Array(paddedLen);
  padded.set(bytes);
  padded[len] = 0x80;
  // Длина в битах — big-endian, 64-битная (берём только младшие 32 бита, для коротких строк хватит)
  const dv = new DataView(padded.buffer);
  dv.setUint32(paddedLen - 4, bitLen >>> 0, false);
  dv.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);

  let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
  let h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

  const w = new Uint32Array(64);

  for (let i = 0; i < paddedLen; i += 64) {
    for (let t = 0; t < 16; t++) {
      w[t] = dv.getUint32(i + t * 4, false);
    }
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(w[t-15], 7) ^ rotr(w[t-15], 18) ^ (w[t-15] >>> 3);
      const s1 = rotr(w[t-2], 17) ^ rotr(w[t-2], 19) ^ (w[t-2] >>> 10);
      w[t] = (w[t-16] + s0 + w[t-7] + s1) >>> 0;
    }

    let a=h0, b=h1, c=h2, d=h3, e=h4, f=h5, g=h6, hh=h7;
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (hh + S1 + ch + SHA256_K[t] + w[t]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;
      hh = g; g = f; f = e; e = (d + temp1) >>> 0;
      d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
    }

    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + hh) >>> 0;
  }

  const out = new Uint8Array(32);
  const odv = new DataView(out.buffer);
  odv.setUint32(0, h0, false); odv.setUint32(4, h1, false); odv.setUint32(8, h2, false); odv.setUint32(12, h3, false);
  odv.setUint32(16, h4, false); odv.setUint32(20, h5, false); odv.setUint32(24, h6, false); odv.setUint32(28, h7, false);

  // Hex-encode
  let hex = '';
  for (let i = 0; i < 32; i++) {
    hex += out[i].toString(16).padStart(2, '0');
  }
  return hex;
}

// ----------------------------------------------------------------------------
// PoW: brute-force SHA-256.
// Алгоритм: ищем такое N, что sha256(challenge + ':' + N) содержит challenge
// в любом месте hex-хэша. Решение занимает 0.5–2 секунды на типичном CPU.
// ----------------------------------------------------------------------------

function solvePoW(challenge) {
  if (!challenge || challenge.length < 3) {
    throw new Error('invalid challenge');
  }
  const challengeLower = challenge.toLowerCase();
  const prefix = challenge + ':';

  // Перебираем, отдавая управление браузеру каждые 4096 итераций.
  let nonce = 0;
  const batchSize = 4096;
  const maxIter = 10_000_000;

  return new Promise((resolve, reject) => {
    function batch() {
      for (let i = 0; i < batchSize; i++, nonce++) {
        if (nonce >= maxIter) {
          reject(new Error('PoW solution not found within iteration limit'));
          return;
        }
        const hex = sha256Hex(prefix + nonce);
        if (hex.indexOf(challengeLower) !== -1) {
          resolve({ nonce: String(nonce), iterations: nonce + 1, hash: hex });
          return;
        }
      }
      // Даём браузеру вздохнуть и обновить UI.
      setTimeout(batch, 0);
    }
    batch();
  });
}

// ----------------------------------------------------------------------------
// Привязка PoW к форме. Запрашивает challenge, решает, заполняет hidden inputs,
// разблокирует submit.
// ----------------------------------------------------------------------------

async function startPoWForForm(formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId) {
  const form = document.getElementById(formId);
  const challengeInput = document.getElementById(challengeInputId);
  const nonceInput = document.getElementById(nonceInputId);
  const status = document.getElementById(statusId);
  const submit = document.getElementById(submitBtnId);

  if (!form || !challengeInput || !nonceInput || !status || !submit) {
    console.warn('PoW: missing elements', { formId, challengeInputId, nonceInputId, statusId, submitBtnId });
    return;
  }

  status.textContent = '⏳ Requesting PoW challenge...';

  // Шаг 1: Запрос challenge
  let challenge;
  try {
    const resp = await fetch('/pow/' + purpose);
    if (!resp.ok) throw new Error('HTTP ' + resp.status + ' — backend unavailable');
    const data = await resp.json();
    challenge = data.challenge;
    if (!challenge) throw new Error('empty challenge in response');
    challengeInput.value = challenge;
  } catch (e) {
    status.innerHTML = `<span class="text-red-600">✗ Cannot fetch PoW challenge: ${e.message}. <a href="/pow/${purpose}" target="_blank" class="underline">test</a></span>`;
    console.error('PoW fetch error', e);
    return;
  }

  // Шаг 2: Решение
  status.innerHTML = `🧮 Solving PoW for challenge <code>${challenge}</code> (0.5–2 sec)...`;
  await new Promise(r => setTimeout(r, 30)); // даём UI отрисоваться

  try {
    const t0 = performance.now();
    const sol = await solvePoW(challenge);
    const dt = (performance.now() - t0) / 1000;

    nonceInput.value = sol.nonce;
    status.innerHTML = `<span class="text-green-600">✓ PoW solved in ${dt.toFixed(2)}s (${sol.iterations.toLocaleString()} iterations)</span>`;
    submit.disabled = false;
  } catch (e) {
    status.innerHTML = `<span class="text-red-600">✗ PoW solver failed: ${e.message}</span>`;
    console.error('PoW solver error', e);
  }
}

// ----------------------------------------------------------------------------
// Защита от "function not defined" при использовании defer.
// Если инлайн-скрипт на странице вызвал startPoWForForm ДО загрузки app.js,
// этот вызов попадёт в очередь _libtd_pow_queue. Когда app.js загрузится,
// мы разгребаем очередь и вызываем функцию по-настоящему.
// ----------------------------------------------------------------------------
window._libtd_pow_queue = window._libtd_pow_queue || [];
window.startPoWForForm = function(formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId) {
  // Если DOM ещё не готов (инлайн-скрипт выполнился в <head>) — отложим до DOMContentLoaded.
  if (document.readyState === 'loading') {
    window._libtd_pow_queue.push([formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId]);
    return;
  }
  // Если элементы ещё не отрисованы (скрипт в head, body не распарсен) — тоже отложим.
  if (!document.getElementById(formId)) {
    window._libtd_pow_queue.push([formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId]);
    return;
  }
  return startPoWForForm(formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId);
};

// Разгребаем очередь, когда DOM готов.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function() {
    while (window._libtd_pow_queue.length > 0) {
      const args = window._libtd_pow_queue.shift();
      startPoWForForm.apply(null, args);
    }
  });
} else {
  // DOM уже готов (we're past DOMContentLoaded)
  while (window._libtd_pow_queue.length > 0) {
    const args = window._libtd_pow_queue.shift();
    startPoWForForm.apply(null, args);
  }
}

// ----------------------------------------------------------------------------
// Reply-to: при клике "↩ Reply" подставляет reply_to_id в форму ответа
// и скроллит к ней.
// ----------------------------------------------------------------------------

function replyTo(replyId, nick) {
  const form = document.getElementById('main-reply-form');
  if (!form) return;

  // Обновляем action формы на URL с replyID.
  const action = form.getAttribute('hx-post') || form.getAttribute('action') || '';
  const baseAction = action.replace(/\/reply\/\d+$/, '/reply');
  const newAction = baseAction.replace(/\/reply$/, '/reply/' + replyId);

  // htmx-форма: меняем hx-post.
  if (form.hasAttribute('hx-post')) {
    form.setAttribute('hx-post', newAction);
  } else {
    form.setAttribute('action', newAction);
  }

  // Подсказка юзеру: цитируемый ник.
  const textarea = form.querySelector('textarea[name="content"]');
  if (textarea) {
    textarea.placeholder = `Replying to ${nick} #${replyId}...`;
    textarea.focus();
  }

  // Прокрутка к форме.
  form.scrollIntoView({ behavior: 'smooth', block: 'center' });

  // htmx перерегистрирует обработчики событий после изменения атрибутов.
  if (window.htmx) {
    window.htmx.process(form);
  }
}

// Сброс формы ответа после отправки (вызывается через hx-on::after-request).
function resetReplyForm(form) {
  form.reset();
  // Возвращаем action на базовый (без /reply/ID).
  let action = form.getAttribute('hx-post') || form.getAttribute('action') || '';
  action = action.replace(/\/reply\/\d+$/, '/reply');
  if (form.hasAttribute('hx-post')) {
    form.setAttribute('hx-post', action);
  } else {
    form.setAttribute('action', action);
  }
  if (window.htmx) {
    window.htmx.process(form);
  }
}

// ----------------------------------------------------------------------------
// File upload helpers.
// ----------------------------------------------------------------------------

function updateFileList(input) {
  const list = document.getElementById('file-list');
  if (!list) return;
  if (!input.files || input.files.length === 0) {
    list.textContent = '';
    return;
  }
  const names = Array.from(input.files).map(f => f.name).join(', ');
  list.textContent = names.length > 60 ? names.slice(0, 60) + '...' : names;
}

// ----------------------------------------------------------------------------
// Глобальный обработчик ошибок HTMX: при 401/403 показывает алерт.
// ----------------------------------------------------------------------------

document.body.addEventListener('htmx:responseError', function (evt) {
  const status = evt.detail.xhr.status;
  if (status === 401) {
    window.location.href = '/login';
  } else if (status === 403) {
    alert('Forbidden: you do not have permission for this action.');
  } else if (status >= 500) {
    console.error('Server error', evt.detail);
  }
});

// ----------------------------------------------------------------------------
// Диагностика: при загрузке страницы пишем в консоль версию и контекст.
// ----------------------------------------------------------------------------

console.log('[libtd] app.js loaded. Secure context:', window.isSecureContext, 'Web Crypto:', !!window.crypto?.subtle);
