package storage

import (
        "context"
        "crypto/rand"
        "encoding/hex"
        "errors"
        "io"
        "os"
        "path/filepath"
        "strings"
)

// LocalFS — реализация FileStorage поверх локальной файловой системы.
// Файлы складываются в RootDir (по умолчанию ./uploads), разложенные по
// двухуровневым папкам во избежание 100k+ файлов в одной директории.
type LocalFS struct {
        RootDir   string // папка, где хранятся файлы
        URLPrefix string // публичный префикс (например "/uploads")
}

// NewLocalFS создаёт LocalFS и гарантирует, что RootDir существует.
func NewLocalFS(rootDir, urlPrefix string) (*LocalFS, error) {
        if rootDir == "" {
                rootDir = "./uploads"
        }
        if err := os.MkdirAll(rootDir, 0o755); err != nil {
                return nil, err
        }
        if urlPrefix == "" {
                urlPrefix = "/uploads"
        }
        return &LocalFS{RootDir: rootDir, URLPrefix: urlPrefix}, nil
}

// Save записывает файл. Имя нормализуется и дополняется случайным суффиксом,
// чтобы избежать коллизий и path traversal.
func (fs *LocalFS) Save(ctx context.Context, reader io.Reader, filename string, _ string) (string, int64, error) {
        safe := sanitize(filename)
        if safe == "" {
                safe = "file"
        }
        // /ab/cd/<name> — двухуровневый sharding
        var rnd [2]byte
        if _, err := rand.Read(rnd[:]); err != nil {
                return "", 0, err
        }
        subA := hex.EncodeToString(rnd[0:1])
        subB := hex.EncodeToString(rnd[1:2])
        dir := filepath.Join(fs.RootDir, subA, subB)
        if err := os.MkdirAll(dir, 0o755); err != nil {
                return "", 0, err
        }
        rel := filepath.ToSlash(filepath.Join(subA, subB, safe))
        full := filepath.Join(fs.RootDir, rel)

        f, err := os.Create(full)
        if err != nil {
                return "", 0, err
        }
        defer f.Close()

        n, err := io.Copy(f, reader)
        if err != nil {
                _ = os.Remove(full)
                return "", 0, err
        }
        return rel, n, nil
}

// Open открывает файл для чтения.
func (fs *LocalFS) Open(_ context.Context, path string) (io.ReadCloser, error) {
        if !isSafePath(path) {
                return nil, errors.New("unsafe path")
        }
        return os.Open(filepath.Join(fs.RootDir, path))
}

// Delete удаляет файл.
func (fs *LocalFS) Delete(_ context.Context, path string) error {
        if !isSafePath(path) {
                return errors.New("unsafe path")
        }
        err := os.Remove(filepath.Join(fs.RootDir, path))
        if err != nil && os.IsNotExist(err) {
                return nil
        }
        return err
}

// URL возвращает публичный путь к файлу.
func (fs *LocalFS) URL(path string) string {
        if path == "" {
                return ""
        }
        return fs.URLPrefix + "/" + path
}

// --- helpers ---

// sanitize приводит имя файла к безопасному виду: убирает пути, пробелы и
// спецсимволы заменяет на "_", обрезает длину.
func sanitize(name string) string {
        name = filepath.Base(name)
        name = strings.TrimSpace(name)
        if name == "" || name == "." || name == ".." {
                return ""
        }
        // Заменяем любые пробельные символы и слэши на "_".
        name = strings.Map(func(r rune) rune {
                if r == ' ' || r == '\t' || r == '\n' || r == '\r' || r == '/' || r == '\\' {
                        return '_'
                }
                return r
        }, name)
        if len(name) > 128 {
                ext := filepath.Ext(name)
                base := strings.TrimSuffix(name, ext)
                if len(base) > 128-len(ext) {
                        base = base[:128-len(ext)]
                }
                name = base + ext
        }
        return name
}

// isSafePath проверяет, что путь — это ровно "<hex>/<hex>/<name>" без переходов.
func isSafePath(p string) bool {
        if p == "" || strings.Contains(p, "..") {
                return false
        }
        clean := filepath.Clean(p)
        if clean != p {
                return false
        }
        return true
}
