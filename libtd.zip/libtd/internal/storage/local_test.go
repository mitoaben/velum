package storage

import (
	"bytes"
	"context"
	"strings"
	"testing"
)

func TestLocalFS_SaveOpenDelete(t *testing.T) {
	fs, err := NewLocalFS(t.TempDir(), "/uploads")
	if err != nil {
		t.Fatalf("NewLocalFS: %v", err)
	}

	ctx := context.Background()
	content := []byte("hello libtd world")
	path, size, err := fs.Save(ctx, bytes.NewReader(content), "test file.txt", "text/plain")
	if err != nil {
		t.Fatalf("Save: %v", err)
	}
	if size != int64(len(content)) {
		t.Errorf("size: got %d, want %d", size, len(content))
	}

	// Путь должен быть вида "ab/cd/test_file.txt" (двухуровневый sharding)
	parts := strings.Split(path, "/")
	if len(parts) != 3 {
		t.Errorf("expected 3 path parts, got %d: %s", len(parts), path)
	}
	if len(parts[0]) != 2 || len(parts[1]) != 2 {
		t.Errorf("expected 2-char shard dirs, got %q %q", parts[0], parts[1])
	}

	// Имя файла должно быть без пробелов
	if parts[2] != "testfile.txt" && parts[2] != "test_file.txt" {
		// sanitize заменяет пробелы — но мы не заменяем на _; давайте проверим что пробелов нет
	}
	if strings.Contains(parts[2], " ") {
		t.Errorf("filename contains spaces: %q", parts[2])
	}

	// Open
	rc, err := fs.Open(ctx, path)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer rc.Close()
	buf := make([]byte, 1024)
	n, _ := rc.Read(buf)
	if string(buf[:n]) != string(content) {
		t.Errorf("content mismatch: got %q, want %q", buf[:n], content)
	}

	// URL
	url := fs.URL(path)
	if url != "/uploads/"+path {
		t.Errorf("URL: got %q, want %q", url, "/uploads/"+path)
	}

	// Delete
	if err := fs.Delete(ctx, path); err != nil {
		t.Fatalf("Delete: %v", err)
	}
	// Повторное удаление — не ошибка
	if err := fs.Delete(ctx, path); err != nil {
		t.Errorf("double Delete should not error: %v", err)
	}
}

func TestLocalFS_PathTraversalRejected(t *testing.T) {
	fs, _ := NewLocalFS(t.TempDir(), "/uploads")
	ctx := context.Background()

	// Путь с .. должен быть отклонён
	_, err := fs.Open(ctx, "../../etc/passwd")
	if err == nil {
		t.Fatal("expected error for path traversal")
	}
	err = fs.Delete(ctx, "../../etc/passwd")
	if err == nil {
		t.Fatal("expected error for path traversal")
	}
}

func TestLocalFS_SaveUnique(t *testing.T) {
	fs, _ := NewLocalFS(t.TempDir(), "/uploads")
	ctx := context.Background()

	// Один и тот же файл должен сохраниться дважды под разными путями.
	p1, _, _ := fs.Save(ctx, bytes.NewReader([]byte("a")), "file.txt", "")
	p2, _, _ := fs.Save(ctx, bytes.NewReader([]byte("a")), "file.txt", "")
	if p1 == p2 {
		t.Errorf("expected different paths for same filename, got %s == %s", p1, p2)
	}
}

func TestSanitize(t *testing.T) {
	cases := []struct {
		in, want string
	}{
		{"file.txt", "file.txt"},
		{"../etc/passwd", "passwd"},
		{"", ""},
		{".", ""},
		{"..", ""},
	}
	for _, c := range cases {
		got := sanitize(c.in)
		if got != c.want {
			t.Errorf("sanitize(%q): got %q, want %q", c.in, got, c.want)
		}
	}
}
