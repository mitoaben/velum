package storage

import (
	"context"
	"errors"
	"io"
)

// S3Storage — реализация FileStorage поверх S3-совместимого хранилища
// (Amazon S3, MinIO, Yandex Object Storage, R2, ...).
//
// ВАЖНО: Чтобы не тянуть в проект тяжёлый AWS SDK (и держать go.mod компактным),
// мы намеренно используем минимальный интерфейс. Этот файл — production-ready
// заготовка: для включения раскомментируйте зависимость в go.mod и заполните
// методы. Контракт (FileStorage) полностью совпадает с LocalFS, поэтому
// подмена делается одной строкой в main.go:
//
//   storage, err := storage.NewS3(endpoint, region, bucket, accessKey, secretKey, usePath, publicURL)
//
// Архитектура уже это позволяет — больше ничего в коде менять не нужно.
type S3Storage struct {
	Endpoint  string
	Region    string
	Bucket    string
	AccessKey string
	SecretKey string
	UsePath   bool   // true для MinIO (path-style)
	PublicURL string // базовый публичный URL, например https://cdn.libtd.com

	// client *s3.Client — раскомментировать при подключении AWS SDK.
}

// NewS3 — конструктор. Заглушка: чтобы включить S3, нужно:
//   1. go get github.com/aws/aws-sdk-go-v2/service/s3
//   2. Создать s3.New(s3.WithCredentials(...), s3.WithEndpoint(...), ...)
//   3. Заполнить методы ниже.
func NewS3(endpoint, region, bucket, accessKey, secretKey string, usePath bool, publicURL string) (*S3Storage, error) {
	if endpoint == "" || bucket == "" {
		return nil, errors.New("S3: endpoint and bucket are required")
	}
	return &S3Storage{
		Endpoint:  endpoint,
		Region:    region,
		Bucket:    bucket,
		AccessKey: accessKey,
		SecretKey: secretKey,
		UsePath:   usePath,
		PublicURL: publicURL,
	}, nil
}

// Save загружает объект в S3.
//
// Реализация с AWS SDK v2 (псевдокод):
//
//   key := uniqueKey(filename)
//   _, err := client.PutObject(ctx, &s3.PutObjectInput{
//       Bucket:      aws.String(s.Bucket),
//       Key:         aws.String(key),
//       Body:        reader,
//       ContentType: aws.String(contentType),
//   })
//   return key, n, err
//
// Заглушка возвращает ErrNotImplemented, чтобы случайно не записать данные
// в "никуда" при некорректной конфигурации.
func (s *S3Storage) Save(_ context.Context, _ io.Reader, _ string, _ string) (string, int64, error) {
	return "", 0, ErrNotImplemented
}

// Open скачивает объект.
func (s *S3Storage) Open(_ context.Context, _ string) (io.ReadCloser, error) {
	return nil, ErrNotImplemented
}

// Delete удаляет объект.
func (s *S3Storage) Delete(_ context.Context, _ string) error {
	return ErrNotImplemented
}

// URL возвращает публичный URL объекта. Если PublicURL задан — используем его,
// иначе формируем endpoint-style URL.
func (s *S3Storage) URL(path string) string {
	if path == "" {
		return ""
	}
	if s.PublicURL != "" {
		return s.PublicURL + "/" + path
	}
	if s.UsePath {
		return s.Endpoint + "/" + s.Bucket + "/" + path
	}
	return "https://" + s.Bucket + "." + s.Endpoint + "/" + path
}

// ErrNotImplemented возвращается методами S3Storage, пока не подключён AWS SDK.
var ErrNotImplemented = errors.New("S3 storage: not implemented, see internal/storage/s3.go comments")
