// Package storage — абстракция над хранилищем файлов форума.
//
// Контракт намеренно минимальный: Save / Open / Delete / URL.
// Это позволяет за 5 минут заменить LocalFS на S3-совместимое хранилище
// (MinIO / Amazon S3), не трогая остальной код.
package storage

import (
	"context"
	"io"
)

// FileStorage — единый интерфейс для записи/чтения вложений форума.
//
// Возвращаемое из Save значение `path` сохраняется в БД (attachments.file_path).
// Оно же передаётся в Open/Delete. URL(path) возвращает публичную ссылку,
// пригодную для <img src> или <a href>.
type FileStorage interface {
	// Save сохраняет файл и возвращает внутренний путь/ключ.
	Save(ctx context.Context, reader io.Reader, filename string, contentType string) (path string, size int64, err error)
	// Open открывает файл для чтения (для отдачи юзеру).
	Open(ctx context.Context, path string) (io.ReadCloser, error)
	// Delete удаляет файл.
	Delete(ctx context.Context, path string) error
	// URL возвращает публичный URL (для src/href). Может быть как относительным
	// (/uploads/foo.png), так и абсолютным (https://cdn.libtd.com/foo.png).
	URL(path string) string
}
