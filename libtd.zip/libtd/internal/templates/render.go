// Package templates — обёртка над html/template с поддержкой layout и фрагментов.
package templates

import (
        "embed"
        "fmt"
        "html/template"
        "io"
        "net/http"
        "path"
        "strings"
)

//go:embed pages/*.html partials/*.html fragments/*.html
var templateFS embed.FS

// Renderer умеет рендерить полные страницы (через layout) и HTMX-фрагменты.
type Renderer struct {
        tmpls *template.Template
}

// New парсит все шаблоны из embed.FS. Вызывается один раз при старте.
func New() (*Renderer, error) {
        funcMap := template.FuncMap{
                "join":          strings.Join,
                "truncate":      truncate,
                "dict":          dict,
                "hasPrefix":     strings.HasPrefix,
                "lower":         strings.ToLower,
                "upper":         strings.ToUpper,
                "ext":           func(name string) string { return path.Ext(name) },
                "safeHTML":      func(s string) template.HTML { return template.HTML(s) },
                "safeURL":       func(s string) template.URL { return template.URL(s) },
                "add":           func(a, b int) int { return a + b },
                "sub":           func(a, b int) int { return a - b },
                "mod":           func(a, b int) int { return a % b },
                "inc":           func(a int) int { return a + 1 },
                "seq":           seq,
                "formatBytes":   formatBytes,
                "formatTime":    formatTime,
                "formatTimeRel": formatTimeRel,
        }

        t, err := template.New("").Funcs(funcMap).ParseFS(templateFS,
                "pages/*.html",
                "partials/*.html",
                "fragments/*.html",
        )
        if err != nil {
                return nil, fmt.Errorf("parse templates: %w", err)
        }
        return &Renderer{tmpls: t}, nil
}

// PageData — стандартный контекст для рендера страницы (включая layout).
type PageData struct {
        Title      string
        CurrentUser interface{} // *models.User или nil
        Active     string        // активный раздел шапки (для подсветки)
        SubscribedBoards interface{} // []models.Board
        Boards     interface{} // []models.Board — все доски для шапки
        Content    template.HTML
        Extra      map[string]any // любые доп. данные для конкретной страницы
}

// RenderPage рендерит страницу с layout.
func (r *Renderer) RenderPage(w io.Writer, name string, data PageData) error {
        // Сначала рендерим содержимое страницы в строку
        content, err := r.renderToString(name, data)
        if err != nil {
                return err
        }
        data.Content = template.HTML(content)
        // Затем рендерим layout
        return r.tmpls.ExecuteTemplate(w, "layout.html", data)
}

// RenderFragment рендерит только указанный шаблон (для HTMX-ответа).
func (r *Renderer) RenderFragment(w io.Writer, name string, data any) error {
        return r.tmpls.ExecuteTemplate(w, name, data)
}

// RenderPageHTTP — обёртка для HTTP-хендлеров: пишет 200 и content-type.
func (r *Renderer) RenderPageHTTP(w http.ResponseWriter, name string, data PageData) {
        w.Header().Set("Content-Type", "text/html; charset=utf-8")
        if err := r.RenderPage(w, name, data); err != nil {
                http.Error(w, "template error: "+err.Error(), http.StatusInternalServerError)
        }
}

// RenderFragmentHTTP — обёртка для HTMX-ответов.
func (r *Renderer) RenderFragmentHTTP(w http.ResponseWriter, name string, data any) {
        w.Header().Set("Content-Type", "text/html; charset=utf-8")
        if err := r.RenderFragment(w, name, data); err != nil {
                http.Error(w, "template error: "+err.Error(), http.StatusInternalServerError)
        }
}

// renderToString рендерит шаблон в строку.
func (r *Renderer) renderToString(name string, data any) (string, error) {
        var sb strings.Builder
        if err := r.tmpls.ExecuteTemplate(&sb, name, data); err != nil {
                return "", err
        }
        return sb.String(), nil
}

// --- FuncMap helpers ---

// truncate обрезает строку до n символов, добавляя "…", если было длиннее.
func truncate(s string, n int) string {
        if len(s) <= n {
                return s
        }
        if n <= 1 {
                return "…"
        }
        return s[:n-1] + "…"
}

// dict создаёт map[string]any из пар "ключ, значение, ключ, значение, ...".
// Полезно в шаблонах: {{dict "key1" $v1 "key2" $v2}}
func dict(pairs ...any) map[string]any {
        m := make(map[string]any, len(pairs)/2)
        for i := 0; i+1 < len(pairs); i += 2 {
                key, _ := pairs[i].(string)
                m[key] = pairs[i+1]
        }
        return m
}

// seq возвращает срез [start, start+1, ..., end]. Удобно для пагинации.
func seq(start, end int) []int {
        if end < start {
                return nil
        }
        out := make([]int, 0, end-start+1)
        for i := start; i <= end; i++ {
                out = append(out, i)
        }
        return out
}

// formatBytes превращает байты в "1.2 MB".
func formatBytes(b int64) string {
        const unit = 1024
        if b < unit {
                return fmt.Sprintf("%d B", b)
        }
        div, exp := int64(unit), 0
        for n := b / unit; n >= unit; n /= unit {
                div *= unit
                exp++
        }
        return fmt.Sprintf("%.1f %ciB", float64(b)/float64(div), "KMGTPE"[exp])
}

// formatTime возвращает "2006-01-02 15:04".
func formatTime(t any) string {
        switch v := t.(type) {
        case interface{ Format(string) string }:
                return v.Format("2006-01-02 15:04")
        }
        return ""
}

// formatTimeRel — относительное время: "5m ago", "2h ago", "3d ago".
func formatTimeRel(t any) string {
        type tter interface{ Format(string) string }
        tt, ok := t.(tter)
        if !ok {
                return ""
        }
        // relying on caller passing time.Time; this is a minimal impl
        return tt.Format("2006-01-02 15:04")
}
