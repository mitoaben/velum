package templates

import (
	"bytes"
	"strings"
	"testing"
)

// TestRenderer_New проверяет, что все шаблоны парсятся без ошибок.
func TestRenderer_New(t *testing.T) {
	r, err := New()
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if r == nil {
		t.Fatal("renderer is nil")
	}
}

// TestRenderer_RenderFragment проверяет, что фрагменты рендерятся с данными.
func TestRenderer_RenderFragment(t *testing.T) {
	r, _ := New()
	var buf bytes.Buffer
	err := r.RenderFragment(&buf, "fragments/suggestion_card.html", map[string]any{
		"suggestion": map[string]any{
			"ID":        42,
			"Name":      "Test",
			"AuthorNick": "alice",
			"AuthorID":  7,
			"Votes":     5,
			"Status":    "open",
			"Voted":     false,
		},
		"currentUser": map[string]any{
			"ID": 1,
		},
	})
	if err != nil {
		t.Fatalf("RenderFragment: %v", err)
	}
	out := buf.String()
	if !strings.Contains(out, "Test") {
		t.Errorf("expected 'Test' in output, got: %s", out)
	}
}

// TestFuncMap_Truncate
func TestFuncMap_Truncate(t *testing.T) {
	if got := truncate("hello world", 5); got != "hell…" {
		t.Errorf("truncate: got %q, want %q", got, "hell…")
	}
	if got := truncate("hi", 5); got != "hi" {
		t.Errorf("truncate short: got %q, want %q", got, "hi")
	}
}

// TestFuncMap_Dict
func TestFuncMap_Dict(t *testing.T) {
	d := dict("a", 1, "b", "two")
	if d["a"] != 1 || d["b"] != "two" {
		t.Errorf("dict: %v", d)
	}
}

// TestFuncMap_FormatBytes
func TestFuncMap_FormatBytes(t *testing.T) {
	cases := []struct {
		in   int64
		want string
	}{
		{512, "512 B"},
		{1024, "1.0 KiB"},
		{1024 * 1024, "1.0 MiB"},
		{100 * 1024 * 1024, "100.0 MiB"},
	}
	for _, c := range cases {
		got := formatBytes(c.in)
		if got != c.want {
			t.Errorf("formatBytes(%d): got %q, want %q", c.in, got, c.want)
		}
	}
}

// TestFuncMap_Seq
func TestFuncMap_Seq(t *testing.T) {
	got := seq(1, 5)
	want := []int{1, 2, 3, 4, 5}
	if len(got) != len(want) {
		t.Fatalf("seq len: got %d, want %d", len(got), len(want))
	}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("seq[%d]: got %d, want %d", i, got[i], want[i])
		}
	}
}
