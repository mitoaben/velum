// app.js — клиентский скрипт libtd.
// Содержит:
//   - PoW-солвер (SHA-256, асинхронно, через Web Crypto API)
//   - Хелперы для форм (drag-n-drop, file list)
//   - HTMX-хелперы (reply-to с цитатой, reset формы)

// ----------------------------------------------------------------------------
// PoW: SHA-256 brute-force.
// Алгоритм: ищем такое N, что sha256(challenge + ':' + N) содержит challenge
// в любом месте hex-хэша. Решение занимает 0.5–2 секунды на типичном CPU.
// ----------------------------------------------------------------------------

async function solvePoW(challenge) {
  if (!challenge || challenge.length < 3) {
    throw new Error('invalid challenge');
  }
  const encoder = new TextEncoder();
  const challengeLower = challenge.toLowerCase();
  // Стартуем с 0 и перебираем, отдавая управление браузеру каждые 4096 итераций,
  // чтобы UI не зависал.
  let nonce = 0;
  const batchSize = 4096;
  while (nonce < 10_000_000) {
    for (let i = 0; i < batchSize; i++, nonce++) {
      const data = encoder.encode(challenge + ':' + nonce);
      const hashBuf = await crypto.subtle.digest('SHA-256', data);
      const hex = bufToHex(hashBuf);
      if (hex.indexOf(challengeLower) !== -1) {
        return { nonce: String(nonce), iterations: nonce + 1, hash: hex };
      }
    }
    // Даём браузеру вздохнуть.
    await new Promise(r => setTimeout(r, 0));
  }
  throw new Error('PoW solution not found within iteration limit');
}

function bufToHex(buf) {
  const bytes = new Uint8Array(buf);
  let hex = '';
  for (let i = 0; i < bytes.length; i++) {
    hex += bytes[i].toString(16).padStart(2, '0');
  }
  return hex;
}

// ----------------------------------------------------------------------------
// Привязка PoW к форме. Запрашивает challenge, решает, заполняет hidden inputs,
// разблокирует submit.
// ----------------------------------------------------------------------------

async function startPoWForForm(formId, purpose, challengeInputId, nonceInputId, statusId, submitBtnId) {
  const form = document.getElementById(formId);
  const challengeInput = document.getElementById(challengeInputId);
  const nonceInput = document.getElementById(nonceInputId);
  const status = document.getElementById(statusId);
  const submit = document.getElementById(submitBtnId);

  if (!form || !challengeInput || !nonceInput || !status || !submit) {
    console.warn('PoW: missing elements', { formId, challengeInputId, nonceInputId, statusId, submitBtnId });
    return;
  }

  status.textContent = 'Requesting PoW challenge...';
  try {
    const resp = await fetch('/pow/' + purpose);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    const challenge = data.challenge;
    challengeInput.value = challenge;

    status.textContent = 'Solving PoW (this takes 0.5–2 seconds)...';
    await new Promise(r => setTimeout(r, 50)); // даём UI отрисоваться

    const t0 = performance.now();
    const sol = await solvePoW(challenge);
    const dt = (performance.now() - t0) / 1000;

    nonceInput.value = sol.nonce;
    status.innerHTML = `<span class="text-green-600">✓ PoW solved in ${dt.toFixed(2)}s (${sol.iterations} iters)</span>`;
    submit.disabled = false;
  } catch (e) {
    status.innerHTML = `<span class="text-red-600">✗ PoW failed: ${e.message}</span>`;
    console.error('PoW error', e);
  }
}

// ----------------------------------------------------------------------------
// Reply-to: при клике "↩ Reply" подставляет reply_to_id в форму ответа
// и скроллит к ней.
// ----------------------------------------------------------------------------

function replyTo(replyId, nick) {
  const form = document.getElementById('main-reply-form');
  if (!form) return;

  // Обновляем action формы на URL с replyID.
  const action = form.getAttribute('hx-post') || form.getAttribute('action') || '';
  const baseAction = action.replace(/\/reply\/\d+$/, '/reply');
  const newAction = baseAction.replace(/\/reply$/, '/reply/' + replyId);

  // htmx-форма: меняем hx-post.
  if (form.hasAttribute('hx-post')) {
    form.setAttribute('hx-post', newAction);
  } else {
    form.setAttribute('action', newAction);
  }

  // Подсказка юзеру: цитируемый ник.
  const textarea = form.querySelector('textarea[name="content"]');
  if (textarea) {
    textarea.placeholder = `Replying to ${nick} #${replyId}...`;
    textarea.focus();
  }

  // Прокрутка к форме.
  form.scrollIntoView({ behavior: 'smooth', block: 'center' });

  // htmx перерегистрирует обработчики событий после изменения атрибутов.
  if (window.htmx) {
    window.htmx.process(form);
  }
}

// Сброс формы ответа после отправки (вызывается через hx-on::after-request).
function resetReplyForm(form) {
  form.reset();
  // Возвращаем action на базовый (без /reply/ID).
  let action = form.getAttribute('hx-post') || form.getAttribute('action') || '';
  action = action.replace(/\/reply\/\d+$/, '/reply');
  if (form.hasAttribute('hx-post')) {
    form.setAttribute('hx-post', action);
  } else {
    form.setAttribute('action', action);
  }
  if (window.htmx) {
    window.htmx.process(form);
  }
}

// ----------------------------------------------------------------------------
// File upload helpers.
// ----------------------------------------------------------------------------

function updateFileList(input) {
  const list = document.getElementById('file-list');
  if (!list) return;
  if (!input.files || input.files.length === 0) {
    list.textContent = '';
    return;
  }
  const names = Array.from(input.files).map(f => f.name).join(', ');
  list.textContent = names.length > 60 ? names.slice(0, 60) + '...' : names;
}

// ----------------------------------------------------------------------------
// Глобальный обработчик ошибок HTMX: при 401/403 показывает алерт.
// ----------------------------------------------------------------------------

document.body.addEventListener('htmx:responseError', function (evt) {
  const status = evt.detail.xhr.status;
  if (status === 401) {
    window.location.href = '/login';
  } else if (status === 403) {
    alert('Forbidden: you do not have permission for this action.');
  } else if (status >= 500) {
    console.error('Server error', evt.detail);
  }
});
